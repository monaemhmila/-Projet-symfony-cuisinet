<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/commande' => [[['_route' => 'commande', '_controller' => 'App\\Controller\\CommandeController::index'], null, null, null, false, false, null]],
        '/AfficherCommandes' => [[['_route' => 'AfficherCommandes', '_controller' => 'App\\Controller\\CommandeController::AfficherCommandes'], null, null, null, false, false, null]],
        '/AjouterCommande' => [[['_route' => 'AjouterCommande', '_controller' => 'App\\Controller\\CommandeController::AjouterCommande'], null, null, null, false, false, null]],
        '/EnrichirPanier' => [[['_route' => 'EnrichirPanier', '_controller' => 'App\\Controller\\CommandeController::EnrechirPanier'], null, null, null, false, false, null]],
        '/AjouterCommandeFront' => [[['_route' => 'AjouterCommandeFront', '_controller' => 'App\\Controller\\CommandeController::AjouterCommandeFront'], null, null, null, false, false, null]],
        '/fournisseur' => [[['_route' => 'app_fournisseur', '_controller' => 'App\\Controller\\FournisseurController::exel'], null, null, null, false, false, null]],
        '/Showfournisseur' => [[['_route' => 'Show_fournisseur', '_controller' => 'App\\Controller\\FournisseurController::products'], null, null, null, false, false, null]],
        '/fournisseurs' => [[['_route' => 'AfficherfournisseurFront', '_controller' => 'App\\Controller\\FournisseurController::AfficherFournisseursFront'], null, null, null, false, false, null]],
        '/ajoutFournisseur' => [[['_route' => 'AjoutFournisseur', '_controller' => 'App\\Controller\\FournisseurController::addproduits'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'homeRedirect', '_controller' => 'App\\Controller\\HomeController::index'], null, null, null, false, false, null]],
        '/home' => [[['_route' => 'home', '_controller' => 'App\\Controller\\HomeController::home'], null, null, null, false, false, null]],
        '/calendar' => [[['_route' => 'calendar', '_controller' => 'App\\Controller\\MainController::index'], null, null, null, false, false, null]],
        '/reset-password' => [[['_route' => 'app_forgot_password_request', '_controller' => 'App\\Controller\\ResetPasswordController::request'], null, null, null, false, false, null]],
        '/reset-password/check-email' => [[['_route' => 'app_check_email', '_controller' => 'App\\Controller\\ResetPasswordController::checkEmail'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
        '/banned' => [[['_route' => 'is_banned', '_controller' => 'App\\Controller\\SecurityController::banned'], null, null, null, false, false, null]],
        '/dashboard' => [[['_route' => 'dashboard', '_controller' => 'App\\Controller\\UserController::index'], null, null, null, false, false, null]],
        '/dashboard/users' => [[['_route' => 'dashboardUsers', '_controller' => 'App\\Controller\\UserController::goToUsers'], null, null, null, false, false, null]],
        '/dashboard/users/AfficherUsers' => [[['_route' => 'AfficherUsers', '_controller' => 'App\\Controller\\UserController::AfficherUsers'], null, null, null, false, false, null]],
        '/dashboard/users/AjouterUser' => [[['_route' => 'AjouterUser', '_controller' => 'App\\Controller\\UserController::AjouterUser'], null, null, null, false, false, null]],
        '/DownloadUsersData' => [[['_route' => 'DownloadUsersData', '_controller' => 'App\\Controller\\UserController::DownloadUsersData'], null, null, null, false, false, null]],
        '/register' => [[['_route' => 'inscrire', '_controller' => 'App\\Controller\\UserController::Inscrire'], null, null, null, false, false, null]],
        '/Profil' => [[['_route' => 'Profil', '_controller' => 'App\\Controller\\UserController::Profil'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/Supprimer(?'
                    .'|Commande/([^/]++)(*:199)'
                    .'|DuPanier/([^/]++)(*:224)'
                .')'
                .'|/Modifier(?'
                    .'|Commande/([^/]++)(*:262)'
                    .'|Profil/([^/]++)(*:285)'
                .')'
                .'|/AjouterAuPanier/([^/]++)(*:319)'
                .'|/DeleteFournisseur/([^/]++)(*:354)'
                .'|/U(?'
                    .'|pdateFournisseur/([^/]++)(*:392)'
                    .'|nbanUser/([^/]++)(*:417)'
                .')'
                .'|/reset\\-password/reset(?:/([^/]++))?(*:462)'
                .'|/dashboard/users/(?'
                    .'|ProfilBack/([^/]++)(*:509)'
                    .'|SupprimerUser/([^/]++)(*:539)'
                    .'|ModifierUser/([^/]++)(*:568)'
                .')'
                .'|/activateAccount/([^/]++)(*:602)'
                .'|/BanUser/([^/]++)(*:627)'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        199 => [[['_route' => 'SupprimerCommande', '_controller' => 'App\\Controller\\CommandeController::SupprimerCommande'], ['id'], null, null, false, true, null]],
        224 => [[['_route' => 'SupprimerDuPanier', '_controller' => 'App\\Controller\\CommandeController::SupprimerDuPanier'], ['id'], null, null, false, true, null]],
        262 => [[['_route' => 'ModifierCommande', '_controller' => 'App\\Controller\\CommandeController::ModifierCommande'], ['id'], null, null, false, true, null]],
        285 => [[['_route' => 'ModifierProfil', '_controller' => 'App\\Controller\\UserController::ModifierProfil'], ['id'], null, null, false, true, null]],
        319 => [[['_route' => 'AjouterAuPanier', '_controller' => 'App\\Controller\\CommandeController::AjouterAuPanier'], ['id'], null, null, false, true, null]],
        354 => [[['_route' => 'delete_fournisseur', '_controller' => 'App\\Controller\\FournisseurController::Delete'], ['id'], null, null, false, true, null]],
        392 => [[['_route' => 'update_fournisseur', '_controller' => 'App\\Controller\\FournisseurController::UpdateProd'], ['id'], null, null, false, true, null]],
        417 => [[['_route' => 'UnbanUser', '_controller' => 'App\\Controller\\UserController::UnbanUser'], ['id'], null, null, false, true, null]],
        462 => [[['_route' => 'app_reset_password', 'token' => null, '_controller' => 'App\\Controller\\ResetPasswordController::reset'], ['token'], null, null, false, true, null]],
        509 => [[['_route' => 'ProfilBack', '_controller' => 'App\\Controller\\UserController::ProfilBack'], ['id'], null, null, false, true, null]],
        539 => [[['_route' => 'SupprimerUser', '_controller' => 'App\\Controller\\UserController::SupprimerUser'], ['id'], null, null, false, true, null]],
        568 => [[['_route' => 'ModifierUser', '_controller' => 'App\\Controller\\UserController::ModifierUser'], ['id'], null, null, false, true, null]],
        602 => [[['_route' => 'ConfirmerCompte', '_controller' => 'App\\Controller\\UserController::confirmerCompte'], ['token'], null, null, false, true, null]],
        627 => [
            [['_route' => 'BanUser', '_controller' => 'App\\Controller\\UserController::BanUser'], ['id'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
