<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* front/resetPassword/check_email.html.twig */
class __TwigTemplate_ff58daa3c87b296d1df40cd61c8540c56e02cfbc3f091a941c0e9cd5a3997449 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/resetPassword/check_email.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/resetPassword/check_email.html.twig"));

        $this->parent = $this->loadTemplate("base-front2.html.twig", "front/resetPassword/check_email.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "
\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('/front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t<div class=\"overlay\"></div>
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t<h1 class=\"mb-2 bread\">Check email</h1>
\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t<a href=\"index.html\">User
\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span>Mot de passe oublié
\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t</span>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>


\t<section class=\"innerpage_all_wrap d-flex flex-col \" style=\"margin-top: 5rem; margin-bottom: 5rem;\" >
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<h2 class=\"heading\">E-mail de réinitialisation du mot de passe
\t\t\t\t\t<span>envoyé !</span>
\t\t\t\t</h2>

\t\t\t\t<p class=\"headParagraph\"></p>


\t\t\t\t<p>
\t\t\t\t\t<h4 style=\"text-align: center\">Si un compte correspondant à votre adresse e-mail existe, un e-mail vient d'être envoyé contenant un lien que vous pouvez utiliser pour réinitialiser votre mot de passe.</h4>
\t\t\t\t\t<h4 style=\"text-align: center; margin-top:10px\">Ce lien expirera dans 1 heure.</h4>
\t\t\t\t\t<h4 style=\"text-align: center; margin-top:10px\">Si vous ne recevez pas d'e-mail, veuillez vérifier votre dossier spam ou
\t\t\t\t\t\t<a href=\"";
        // line 40
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_forgot_password_request");
        echo "\">réessayer</a>.</h4>
\t\t\t\t</p>


\t\t\t</div>


\t\t</div>
\t</div>
</section></div></section>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "front/resetPassword/check_email.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 40,  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front2.html.twig' %}
{% block content %}

\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('/front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t<div class=\"overlay\"></div>
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t<h1 class=\"mb-2 bread\">Check email</h1>
\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t<a href=\"index.html\">User
\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span>Mot de passe oublié
\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t</span>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>


\t<section class=\"innerpage_all_wrap d-flex flex-col \" style=\"margin-top: 5rem; margin-bottom: 5rem;\" >
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<h2 class=\"heading\">E-mail de réinitialisation du mot de passe
\t\t\t\t\t<span>envoyé !</span>
\t\t\t\t</h2>

\t\t\t\t<p class=\"headParagraph\"></p>


\t\t\t\t<p>
\t\t\t\t\t<h4 style=\"text-align: center\">Si un compte correspondant à votre adresse e-mail existe, un e-mail vient d'être envoyé contenant un lien que vous pouvez utiliser pour réinitialiser votre mot de passe.</h4>
\t\t\t\t\t<h4 style=\"text-align: center; margin-top:10px\">Ce lien expirera dans 1 heure.</h4>
\t\t\t\t\t<h4 style=\"text-align: center; margin-top:10px\">Si vous ne recevez pas d'e-mail, veuillez vérifier votre dossier spam ou
\t\t\t\t\t\t<a href=\"{{ path('app_forgot_password_request') }}\">réessayer</a>.</h4>
\t\t\t\t</p>


\t\t\t</div>


\t\t</div>
\t</div>
</section></div></section>{% endblock %}{#
\t<p>
\t    This link will expire in {{ resetToken.expirationMessageKey|trans(resetToken.expirationMessageData, 'ResetPasswordBundle') }}.
\t</p>
\t#}
", "front/resetPassword/check_email.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\front\\resetPassword\\check_email.html.twig");
    }
}
