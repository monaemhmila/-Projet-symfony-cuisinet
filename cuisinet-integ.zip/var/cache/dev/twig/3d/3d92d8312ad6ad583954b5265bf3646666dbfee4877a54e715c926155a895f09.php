<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* joueur/Affiche.html.twig */
class __TwigTemplate_6448c2467c2ce00fe82503ff44dbd4ae44a6718e46744252f2accda69c8b539c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'user' => [$this, 'block_user'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-back.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "joueur/Affiche.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "joueur/Affiche.html.twig"));

        $this->parent = $this->loadTemplate("base-back.html.twig", "joueur/Affiche.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_user($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        // line 4
        echo "    ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 4, $this->source); })()), "user", [], "any", false, false, false, 4), "username", [], "any", false, false, false, 4), "html", null, true);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 8
        echo "
    <div class=\"row\" style=\"width: 100%;\">
        <div class=\"col-12\">
            <div class=\"card\">
                <div class=\"page-title-right\">
                    <ol class=\"breadcrumb m-0\">
                        <li class=\"breadcrumb-item\"><a href=\"";
        // line 14
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficheJoueur");
        echo "\">Joueur</a></li>
                        <li class=\"breadcrumb-item active\">Afficher</li>
                    </ol>
                    <div class=\"card-body\">
                        <div class=\"button-items\">
                            <a  href=\"";
        // line 19
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AjouterJoueur");
        echo "\" class=\"btn btn-dark waves-effect waves-light\" >Ajouter</a>
                        </div>
                    </div>
                </div>
                <div class=\"card-body\">

                    <h4 class=\"card-title\">Liste Des Joueurs</h4>
                    ";
        // line 26
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 26, $this->source); })()), "flashes", [0 => "info"], "method", false, false, false, 26));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 27
            echo "                        <div class=\"alert alert-success\">
                            ";
            // line 28
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 31
        echo "                    <table id=\"datatable-buttons\" class=\"table table-striped table-bordered dt-responsive nowrap\" style=\"border-collapse: collapse; border-spacing: 0; width: 100%;\">
                        <thead class=\"thead-light\">
                        <tr>
                            <th>ID</th>
                            <th>Nom Joueur</th>
                            <th>Prenom Joueur</th>
                            <th>Age</th>
                            <th>Photo</th>
                            <th>Position</th>
                            <th>Description</th>
                            <th>Equipe</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr ";
        // line 46
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["joueur"]) || array_key_exists("joueur", $context) ? $context["joueur"] : (function () { throw new RuntimeError('Variable "joueur" does not exist.', 46, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["j"]) {
            echo ">
                            <td>";
            // line 47
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["j"], "id", [], "any", false, false, false, 47), "html", null, true);
            echo "</td>
                            <td>";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["j"], "nomJoueur", [], "any", false, false, false, 48), "html", null, true);
            echo "</td>
                            <td>";
            // line 49
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["j"], "prenomJoueur", [], "any", false, false, false, 49), "html", null, true);
            echo "</td>
                            <td>";
            // line 50
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["j"], "age", [], "any", false, false, false, 50), "html", null, true);
            echo "</td>
                            <td><img style=\"height: 100px\" src=\"";
            // line 51
            echo twig_escape_filter($this->env, ($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/images/") . twig_get_attribute($this->env, $this->source, $context["j"], "photo", [], "any", false, false, false, 51)), "html", null, true);
            echo "\"/></td>
                            <td>";
            // line 52
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["j"], "position", [], "any", false, false, false, 52), "html", null, true);
            echo "</td>
                            <td>";
            // line 53
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["j"], "description", [], "any", false, false, false, 53), "html", null, true);
            echo "</td>
                            <td> ";
            // line 54
            if (twig_get_attribute($this->env, $this->source, $context["j"], "equipe", [], "any", false, false, false, 54)) {
                // line 55
                echo "                                    ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["j"], "equipe", [], "any", false, false, false, 55), "NomEquipe", [], "any", false, false, false, 55), "html", null, true);
                echo "
                                ";
            }
            // line 56
            echo "</td>
                            <td>
                                <a href=\"";
            // line 58
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("update", ["id" => twig_get_attribute($this->env, $this->source, $context["j"], "id", [], "any", false, false, false, 58)]), "html", null, true);
            echo "\" class=\"mr-3 text-primary\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Modifier\" data-original-title=\"Edit\"><i class=\"mdi mdi-pencil font-size-18\"></i></a>
                                <a href=\"";
            // line 59
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete", ["id" => twig_get_attribute($this->env, $this->source, $context["j"], "id", [], "any", false, false, false, 59)]), "html", null, true);
            echo "\" class=\"text-danger\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Supprimer\" data-original-title=\"Delete\"><i class=\"mdi mdi-trash-can font-size-18\"></i></a>
                            </td>
                        </tr ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['j'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo ">
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
    <script>
        \$('#datatable-buttons').DataTable();
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "joueur/Affiche.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  210 => 61,  201 => 59,  197 => 58,  193 => 56,  187 => 55,  185 => 54,  181 => 53,  177 => 52,  173 => 51,  169 => 50,  165 => 49,  161 => 48,  157 => 47,  151 => 46,  134 => 31,  125 => 28,  122 => 27,  118 => 26,  108 => 19,  100 => 14,  92 => 8,  82 => 7,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-back.html.twig' %}

{% block user %}
    {{ app.user.username }}
{% endblock %}

{% block content %}

    <div class=\"row\" style=\"width: 100%;\">
        <div class=\"col-12\">
            <div class=\"card\">
                <div class=\"page-title-right\">
                    <ol class=\"breadcrumb m-0\">
                        <li class=\"breadcrumb-item\"><a href=\"{{ path('AfficheJoueur') }}\">Joueur</a></li>
                        <li class=\"breadcrumb-item active\">Afficher</li>
                    </ol>
                    <div class=\"card-body\">
                        <div class=\"button-items\">
                            <a  href=\"{{ path('AjouterJoueur') }}\" class=\"btn btn-dark waves-effect waves-light\" >Ajouter</a>
                        </div>
                    </div>
                </div>
                <div class=\"card-body\">

                    <h4 class=\"card-title\">Liste Des Joueurs</h4>
                    {% for message in app.flashes('info') %}
                        <div class=\"alert alert-success\">
                            {{ message }}
                        </div>
                    {% endfor %}
                    <table id=\"datatable-buttons\" class=\"table table-striped table-bordered dt-responsive nowrap\" style=\"border-collapse: collapse; border-spacing: 0; width: 100%;\">
                        <thead class=\"thead-light\">
                        <tr>
                            <th>ID</th>
                            <th>Nom Joueur</th>
                            <th>Prenom Joueur</th>
                            <th>Age</th>
                            <th>Photo</th>
                            <th>Position</th>
                            <th>Description</th>
                            <th>Equipe</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr {% for j in joueur %}>
                            <td>{{ j.id }}</td>
                            <td>{{ j.nomJoueur }}</td>
                            <td>{{ j.prenomJoueur }}</td>
                            <td>{{ j.age }}</td>
                            <td><img style=\"height: 100px\" src=\"{{ asset('uploads/images/') ~ j.photo }}\"/></td>
                            <td>{{ j.position }}</td>
                            <td>{{ j.description }}</td>
                            <td> {% if j.equipe %}
                                    {{ j.equipe.NomEquipe }}
                                {% endif %}</td>
                            <td>
                                <a href=\"{{ path('update',{'id':j.id}) }}\" class=\"mr-3 text-primary\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Modifier\" data-original-title=\"Edit\"><i class=\"mdi mdi-pencil font-size-18\"></i></a>
                                <a href=\"{{ path('delete',{'id':j.id}) }}\" class=\"text-danger\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Supprimer\" data-original-title=\"Delete\"><i class=\"mdi mdi-trash-can font-size-18\"></i></a>
                            </td>
                        </tr {% endfor %}>
                        </tbody>
                    </table>
                </div>
            </div>
        </div> <!-- end col -->
    </div> <!-- end row -->
    <script>
        \$('#datatable-buttons').DataTable();
    </script>
{% endblock %}

", "joueur/Affiche.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\joueur\\Affiche.html.twig");
    }
}
