<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* security/login.html.twig */
class __TwigTemplate_96cd5d7c97bcdfaa663978dae18897d184cab39776f9a2ed2a2dacb4b7e405c4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $this->parent = $this->loadTemplate("base-front.html.twig", "security/login.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "
\t<div style=\"height: 20rem;\"></div>
\t<section class=\"innerpage_all_wrap\">
\t\t<div class=\"container\">
\t\t\t";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 7, $this->source); })()), "flashes", [0 => "success"], "method", false, false, false, 7));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 8
            echo "\t\t\t\t<div class=\"alert alert-success\">
\t\t\t\t\t";
            // line 9
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
\t\t\t\t</div>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 12
        echo "\t\t\t<div class=\"row\">
\t\t\t\t<h2 class=\"heading\">
\t\t\t\t\t<div class=\"satisfy\">Connectez-vous pour Continuer
\t\t\t\t\t\t<span>vers Cuisinet</span>
\t\t\t\t\t</div>
\t\t\t\t</h2>

\t\t\t\t<p class=\"headParagraph\"></p>

\t\t\t\t<form action=\"\" method=\"post\">

\t\t\t\t\t";
        // line 23
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 23, $this->source); })())) {
            // line 24
            echo "\t\t\t\t\t\t<div class=\"alert alert-danger\">les informations d'identification invalides !</div>
\t\t\t\t\t";
        }
        // line 26
        echo "
\t\t\t\t\t";
        // line 27
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 27, $this->source); })()), "user", [], "any", false, false, false, 27)) {
            // line 28
            echo "\t\t\t\t\t\t<div class=\"mb-3\">
\t\t\t\t\t\t\tVous êtes connecté en tant que
\t\t\t\t\t\t\t";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 30, $this->source); })()), "user", [], "any", false, false, false, 30), "username", [], "any", false, false, false, 30), "html", null, true);
            echo ",
\t\t\t\t\t\t\t<a href=\"";
            // line 31
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\">Se déconnecter</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 34
        echo "
\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t<input style=\"height: 60px; width: 49%; float: left; margin-right: 1% \" type=\"text\" value=\"";
        // line 36
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new RuntimeError('Variable "last_username" does not exist.', 36, $this->source); })()), "html", null, true);
        echo "\" name=\"username\" id=\"inputUsername\" class=\"form-control\" autocomplete=\"username\" required autofocus placeholder=\"Nom d'utilisateur\">
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t<input style=\"height: 60px; width: 49%; margin-left: 1% \" type=\"password\" name=\"password\" id=\"inputPassword\" class=\"form-control\" autocomplete=\"current-password\" required placeholder=\"Mot de Passe\">
\t\t\t\t\t</div>

\t\t\t\t\t<input
\t\t\t\t\ttype=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\">

\t\t\t\t\t";
        // line 55
        echo "

\t\t\t\t\t<button type=\"submit\" class=\"btn btn-red\">Connexion</button>
\t\t\t\t\t<div class=\"form-message\"></div>

\t\t\t\t\t<div style=\"margin-top: 10px\">
\t\t\t\t\t\t<a href=\"";
        // line 61
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("inscrire");
        echo "\" class=\"text-muted\">
\t\t\t\t\t\t\t<h4>S'inscrire</h4>
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>


\t\t\t\t\t<div style=\"margin-top: 10px\" class=\"mt-4\">
\t\t\t\t\t\t<a href=\"";
        // line 68
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_forgot_password_request");
        echo "\" class=\"text-muted\">
\t\t\t\t\t\t\t<i class=\"mdi mdi-lock mr-1\"></i>
\t\t\t\t\t\t\tMot de passe oublié?</a>
\t\t\t\t\t</div>


\t\t\t\t</form>
\t\t\t</div>


\t\t</div>
\t</div>
</section>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  166 => 68,  156 => 61,  148 => 55,  143 => 44,  132 => 36,  128 => 34,  122 => 31,  118 => 30,  114 => 28,  112 => 27,  109 => 26,  105 => 24,  103 => 23,  90 => 12,  81 => 9,  78 => 8,  74 => 7,  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front.html.twig' %}
{% block content %}

\t<div style=\"height: 20rem;\"></div>
\t<section class=\"innerpage_all_wrap\">
\t\t<div class=\"container\">
\t\t\t{% for message in app.flashes('success') %}
\t\t\t\t<div class=\"alert alert-success\">
\t\t\t\t\t{{ message }}
\t\t\t\t</div>
\t\t\t{% endfor %}
\t\t\t<div class=\"row\">
\t\t\t\t<h2 class=\"heading\">
\t\t\t\t\t<div class=\"satisfy\">Connectez-vous pour Continuer
\t\t\t\t\t\t<span>vers Cuisinet</span>
\t\t\t\t\t</div>
\t\t\t\t</h2>

\t\t\t\t<p class=\"headParagraph\"></p>

\t\t\t\t<form action=\"\" method=\"post\">

\t\t\t\t\t{% if error %}
\t\t\t\t\t\t<div class=\"alert alert-danger\">les informations d'identification invalides !</div>
\t\t\t\t\t{% endif %}

\t\t\t\t\t{% if app.user %}
\t\t\t\t\t\t<div class=\"mb-3\">
\t\t\t\t\t\t\tVous êtes connecté en tant que
\t\t\t\t\t\t\t{{ app.user.username }},
\t\t\t\t\t\t\t<a href=\"{{ path('app_logout') }}\">Se déconnecter</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t{% endif %}

\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t<input style=\"height: 60px; width: 49%; float: left; margin-right: 1% \" type=\"text\" value=\"{{ last_username }}\" name=\"username\" id=\"inputUsername\" class=\"form-control\" autocomplete=\"username\" required autofocus placeholder=\"Nom d'utilisateur\">
\t\t\t\t\t</div>

\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t<input style=\"height: 60px; width: 49%; margin-left: 1% \" type=\"password\" name=\"password\" id=\"inputPassword\" class=\"form-control\" autocomplete=\"current-password\" required placeholder=\"Mot de Passe\">
\t\t\t\t\t</div>

\t\t\t\t\t<input
\t\t\t\t\ttype=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\">

\t\t\t\t\t{#
\t\t\t\t\t                    See https://symfony.com/doc/current/security/remember_me.html
\t\t\t\t\t
\t\t\t\t\t                    <div class=\"checkbox mb-3\">
\t\t\t\t\t                        <label>
\t\t\t\t\t                            <input type=\"checkbox\" name=\"_remember_me\"> Remember me
\t\t\t\t\t                        </label>
\t\t\t\t\t                    </div>
\t\t\t\t\t                    #}


\t\t\t\t\t<button type=\"submit\" class=\"btn btn-red\">Connexion</button>
\t\t\t\t\t<div class=\"form-message\"></div>

\t\t\t\t\t<div style=\"margin-top: 10px\">
\t\t\t\t\t\t<a href=\"{{ path('inscrire') }}\" class=\"text-muted\">
\t\t\t\t\t\t\t<h4>S'inscrire</h4>
\t\t\t\t\t\t</a>
\t\t\t\t\t</div>


\t\t\t\t\t<div style=\"margin-top: 10px\" class=\"mt-4\">
\t\t\t\t\t\t<a href=\"{{ path('app_forgot_password_request') }}\" class=\"text-muted\">
\t\t\t\t\t\t\t<i class=\"mdi mdi-lock mr-1\"></i>
\t\t\t\t\t\t\tMot de passe oublié?</a>
\t\t\t\t\t</div>


\t\t\t\t</form>
\t\t\t</div>


\t\t</div>
\t</div>
</section>{% endblock %}
", "security/login.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\security\\login.html.twig");
    }
}
