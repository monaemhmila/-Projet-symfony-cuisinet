<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* hebergement/AfficheRF.html.twig */
class __TwigTemplate_9a95df11c7fabb7d5f2d6b734be242d15393b4686eb5c33825f13e30a072435c extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'activeHebergements' => [$this, 'block_activeHebergements'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "hebergement/AfficheRF.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "hebergement/AfficheRF.html.twig"));

        $this->parent = $this->loadTemplate("base-front.html.twig", "hebergement/AfficheRF.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_activeHebergements($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeHebergements"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeHebergements"));

        // line 3
        echo "    class=active
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 7
        echo "<div class=innerbannerwrap>
    <div class=content></div>
    <div   class=innerbanner><h2 class=bannerHeadline><span>    Mes Réservations  </span> </h2></div>
</div>
    <section class=playerDetails02>
    <div class=container>
        <div class=row>
                <div class=\"matchSchedule_details row\">
                    <div class=match_next>
                        <div class=\"wrap_match_next right-triangle\">
                            <div class=right-padding><h4 class=headline03> table de Reservation</h4>

                                <p>Dans ce tableau on vous affiche tous vos réservation, vous pouvez aussi modifier ou annuler vos réservation</p></div>
                        </div>
                    </div>
                    <div class=match_versus-wrap>
                        <div class=wrap_match-innerdetails>
                            <ul class=\"point_table scrollable\">
                                ";
        // line 25
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 25, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["r"]) {
            // line 26
            echo "                                <li class=clearfix>
                                    <div class=subPoint_table>
                                        <div class=\"ticketInner_info paragraph02 clearfix\"><b> Mr ";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["r"], "user", [], "any", false, false, false, 28), "nom", [], "any", false, false, false, 28), "html", null, true);
            echo " </b> <b> Vous avez Resrevé à</b> ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["r"], "hebergement", [], "any", false, false, false, 28), "NomH", [], "any", false, false, false, 28), "html", null, true);
            echo " <b> du :  </b><b> ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["r"], "dateDebut", [], "any", false, false, false, 28), "d-m-Y"), "html", null, true);
            echo "   </b><b>  jusqu'a :   </b> <b> ";
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["r"], "dateFin", [], "any", false, false, false, 28), "d-m-Y"), "html", null, true);
            echo "   </b></div>
                                       


                                        <div > <b> <a style=\"margin-right: 9px\" class=\"btn btn-red\" href=\"";
            // line 32
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("UpdateRF", ["id" => twig_get_attribute($this->env, $this->source, $context["r"], "id", [], "any", false, false, false, 32)]), "html", null, true);
            echo "\" >Modifier</a> </b> <b><a class=\"btn btn-red\" href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("deleteRF", ["id" => twig_get_attribute($this->env, $this->source, $context["r"], "id", [], "any", false, false, false, 32)]), "html", null, true);
            echo "\">Annuler</a> </b> <b> <a style=\"margin-top: 10px\" class=\"btn btn-red\" href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficheRI", ["id" => twig_get_attribute($this->env, $this->source, $context["r"], "id", [], "any", false, false, false, 32)]), "html", null, true);
            echo "\">Imprimer</a> </b></div>

                                    </div>
                                </li>
                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['r'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        </section>
        <script type=text/javascript>
            \$(function () {
                \$('#da_gallery .gallery-list ').hoverdir();
            });
        </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "hebergement/AfficheRF.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  146 => 37,  131 => 32,  118 => 28,  114 => 26,  110 => 25,  90 => 7,  80 => 6,  69 => 3,  59 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front.html.twig' %}
{% block activeHebergements %}
    class=active
{% endblock %}

{% block content %}
<div class=innerbannerwrap>
    <div class=content></div>
    <div   class=innerbanner><h2 class=bannerHeadline><span>    Mes Réservations  </span> </h2></div>
</div>
    <section class=playerDetails02>
    <div class=container>
        <div class=row>
                <div class=\"matchSchedule_details row\">
                    <div class=match_next>
                        <div class=\"wrap_match_next right-triangle\">
                            <div class=right-padding><h4 class=headline03> table de Reservation</h4>

                                <p>Dans ce tableau on vous affiche tous vos réservation, vous pouvez aussi modifier ou annuler vos réservation</p></div>
                        </div>
                    </div>
                    <div class=match_versus-wrap>
                        <div class=wrap_match-innerdetails>
                            <ul class=\"point_table scrollable\">
                                {% for r in reservation %}
                                <li class=clearfix>
                                    <div class=subPoint_table>
                                        <div class=\"ticketInner_info paragraph02 clearfix\"><b> Mr {{ r.user.nom }} </b> <b> Vous avez Resrevé à</b> {{ r.hebergement.NomH }} <b> du :  </b><b> {{ r.dateDebut|date('d-m-Y') }}   </b><b>  jusqu'a :   </b> <b> {{ r.dateFin|date('d-m-Y') }}   </b></div>
                                       


                                        <div > <b> <a style=\"margin-right: 9px\" class=\"btn btn-red\" href=\"{{ path('UpdateRF',{'id':r.id}) }}\" >Modifier</a> </b> <b><a class=\"btn btn-red\" href=\"{{ path('deleteRF',{'id':r.id}) }}\">Annuler</a> </b> <b> <a style=\"margin-top: 10px\" class=\"btn btn-red\" href=\"{{ path('AfficheRI',{'id':r.id}) }}\">Imprimer</a> </b></div>

                                    </div>
                                </li>
                                {% endfor %}

                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        </section>
        <script type=text/javascript>
            \$(function () {
                \$('#da_gallery .gallery-list ').hoverdir();
            });
        </script>
{% endblock %}
", "hebergement/AfficheRF.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\hebergement\\AfficheRF.html.twig");
    }
}
