<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* joueur/Ajouter.html.twig */
class __TwigTemplate_2ddef2200c9eb31cc0aac1fcd9b0b0e244cf16863d1ede7846b7c2ce15862e17 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'user' => [$this, 'block_user'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 2
        return "base-back.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "joueur/Ajouter.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "joueur/Ajouter.html.twig"));

        $this->parent = $this->loadTemplate("base-back.html.twig", "joueur/Ajouter.html.twig", 2);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 4
    public function block_user($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        // line 5
        echo "  ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 5, $this->source); })()), "user", [], "any", false, false, false, 5), "username", [], "any", false, false, false, 5), "html", null, true);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 9
        echo "  ";
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 9, $this->source); })()), [0 => "bootstrap_4_layout.html.twig"], true);
        // line 10
        echo "  <div class=\"row\" style=\"width: 100%;\">
    <div class=\"col-12\">
      <div class=\"card\">
        <div class=\"page-title-right\">
          <ol class=\"breadcrumb m-0\">
            <li class=\"breadcrumb-item\"><a href=\"";
        // line 15
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AjouterJoueur");
        echo "\">Joueur</a></li>
            <li class=\"breadcrumb-item active\">Ajouter</li>
          </ol>
        </div>
        <div class=\"card-body\">
          ";
        // line 20
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 20, $this->source); })()), 'form_start', ["attr" => ["novalidate" => "novalidate"]]);
        echo "
          <div class=\"form-group row\">
            <label for=\"example-text-input\" class=\"col-md-2 col-form-label\">";
        // line 22
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 22, $this->source); })()), "nom_joueur", [], "any", false, false, false, 22), 'label');
        echo "</label>
            <div class=\"col-md-10\">
              <input class=\"form-control\" ";
        // line 24
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 24, $this->source); })()), "nom_joueur", [], "any", false, false, false, 24), 'widget');
        echo "
            </div>
          </div>
          <div class=\"form-group row\">
            <label for=\"example-text-input\" class=\"col-md-2 col-form-label\">";
        // line 28
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 28, $this->source); })()), "prenom_joueur", [], "any", false, false, false, 28), 'label');
        echo "</label>
            <div class=\"col-md-10\">
              <input class=\"form-control\" ";
        // line 30
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 30, $this->source); })()), "prenom_joueur", [], "any", false, false, false, 30), 'widget');
        echo "
            </div>
          </div>
          <div class=\"form-group row\">
            <label for=\"example-text-input\" class=\"col-md-2 col-form-label\">";
        // line 34
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 34, $this->source); })()), "age", [], "any", false, false, false, 34), 'label');
        echo "</label>
            <div class=\"col-md-10\">
              <input class=\"form-control\" ";
        // line 36
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 36, $this->source); })()), "age", [], "any", false, false, false, 36), 'widget');
        echo "
            </div>
          </div>
          <div class=\"form-group row\">
            <label for=\"example-text-input\" class=\"col-md-2 col-form-label\">";
        // line 40
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 40, $this->source); })()), "position", [], "any", false, false, false, 40), 'label');
        echo "</label>
            <div class=\"col-md-10\">
              <input class=\"form-control\" ";
        // line 42
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 42, $this->source); })()), "position", [], "any", false, false, false, 42), 'widget');
        echo "
            </div>
          </div>
          <div class=\"form-group row\">
            <label for=\"example-text-input\" class=\"col-md-2 col-form-label\">";
        // line 46
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 46, $this->source); })()), "description", [], "any", false, false, false, 46), 'label');
        echo "</label>
            <div class=\"col-md-10\">
              <input class=\"form-control\" ";
        // line 48
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 48, $this->source); })()), "description", [], "any", false, false, false, 48), 'widget');
        echo "
            </div>
          </div>
          ";
        // line 51
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 51, $this->source); })()), 'form_end');
        echo "
        </div>
      </div> <!-- end col -->
    </div>
  </div>
  <div class=\"row\">

  </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "joueur/Ajouter.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  174 => 51,  168 => 48,  163 => 46,  156 => 42,  151 => 40,  144 => 36,  139 => 34,  132 => 30,  127 => 28,  120 => 24,  115 => 22,  110 => 20,  102 => 15,  95 => 10,  92 => 9,  82 => 8,  69 => 5,  59 => 4,  36 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("
{% extends 'base-back.html.twig' %}

{% block user %}
  {{ app.user.username }}
{% endblock %}

{% block content %}
  {% form_theme form 'bootstrap_4_layout.html.twig' %}
  <div class=\"row\" style=\"width: 100%;\">
    <div class=\"col-12\">
      <div class=\"card\">
        <div class=\"page-title-right\">
          <ol class=\"breadcrumb m-0\">
            <li class=\"breadcrumb-item\"><a href=\"{{ path('AjouterJoueur') }}\">Joueur</a></li>
            <li class=\"breadcrumb-item active\">Ajouter</li>
          </ol>
        </div>
        <div class=\"card-body\">
          {{ form_start(form,{'attr': {'novalidate': 'novalidate'}}) }}
          <div class=\"form-group row\">
            <label for=\"example-text-input\" class=\"col-md-2 col-form-label\">{{ form_label(form.nom_joueur) }}</label>
            <div class=\"col-md-10\">
              <input class=\"form-control\" {{ form_widget(form.nom_joueur) }}
            </div>
          </div>
          <div class=\"form-group row\">
            <label for=\"example-text-input\" class=\"col-md-2 col-form-label\">{{ form_label(form.prenom_joueur) }}</label>
            <div class=\"col-md-10\">
              <input class=\"form-control\" {{ form_widget(form.prenom_joueur) }}
            </div>
          </div>
          <div class=\"form-group row\">
            <label for=\"example-text-input\" class=\"col-md-2 col-form-label\">{{ form_label(form.age) }}</label>
            <div class=\"col-md-10\">
              <input class=\"form-control\" {{ form_widget(form.age) }}
            </div>
          </div>
          <div class=\"form-group row\">
            <label for=\"example-text-input\" class=\"col-md-2 col-form-label\">{{ form_label(form.position) }}</label>
            <div class=\"col-md-10\">
              <input class=\"form-control\" {{ form_widget(form.position) }}
            </div>
          </div>
          <div class=\"form-group row\">
            <label for=\"example-text-input\" class=\"col-md-2 col-form-label\">{{ form_label(form.description) }}</label>
            <div class=\"col-md-10\">
              <input class=\"form-control\" {{ form_widget(form.description) }}
            </div>
          </div>
          {{ form_end(form) }}
        </div>
      </div> <!-- end col -->
    </div>
  </div>
  <div class=\"row\">

  </div>
{% endblock %}


", "joueur/Ajouter.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\joueur\\Ajouter.html.twig");
    }
}
