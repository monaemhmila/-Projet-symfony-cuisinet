<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/download.html.twig */
class __TwigTemplate_124a91b5646fdaed24cab2183225327dac11737e0579cfae85c890d69aab81fe extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/download.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/download.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
\t<head>
\t\t<meta charset=\"UTF-8\">
\t\t<title>Tableau des Utilisateurs</title>
\t</head>
\t<body>
\t\t<h1 style=\"text-align: center; color: red\">Cuisinet Services</h1>
\t\t<h2 style=\"text-align: center\">Tableau des Utilisateurs</h2>

\t\t<table border=\"1\">
\t\t\t<thead>
\t\t\t\t<tr>
\t\t\t\t\t<th>ID</th>
\t\t\t\t\t<th>Username</th>
\t\t\t\t\t<th>Nom</th>
\t\t\t\t\t<th>Prenom</th>
\t\t\t\t\t<th>Email</th>
\t\t\t\t\t<th>Statut</th>
\t\t\t\t\t<th>Role</th>
\t\t\t\t</tr>
\t\t\t</thead>
\t\t\t<tbody>
\t\t\t\t";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["users"]) || array_key_exists("users", $context) ? $context["users"] : (function () { throw new RuntimeError('Variable "users" does not exist.', 24, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["u"]) {
            // line 25
            echo "\t\t\t\t\t<tr>
\t\t\t\t\t\t<td>";
            // line 26
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["u"], "id", [], "any", false, false, false, 26), "html", null, true);
            echo "</td>
\t\t\t\t\t\t<td>";
            // line 27
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["u"], "username", [], "any", false, false, false, 27), "html", null, true);
            echo "</td>
\t\t\t\t\t\t<td>";
            // line 28
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["u"], "nom", [], "any", false, false, false, 28), "html", null, true);
            echo "</td>
\t\t\t\t\t\t<td>";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["u"], "prenom", [], "any", false, false, false, 29), "html", null, true);
            echo "</td>
\t\t\t\t\t\t<td>";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["u"], "email", [], "any", false, false, false, 30), "html", null, true);
            echo "</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t";
            // line 32
            if ((twig_get_attribute($this->env, $this->source, $context["u"], "isBanned", [], "any", false, false, false, 32) == 1)) {
                // line 33
                echo "\t\t\t\t\t\t\t\t<span class=\"badge badge-danger\">Banni</span>
\t\t\t\t\t\t\t";
            } else {
                // line 35
                echo "\t\t\t\t\t\t\t\t<span class=\"badge badge-success\">Actif</span>
\t\t\t\t\t\t\t";
            }
            // line 37
            echo "
\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t";
            // line 40
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["u"], "roles", [], "any", false, false, false, 40));
            foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
                // line 41
                echo "\t\t\t\t\t\t\t\t";
                if (($context["role"] == "ROLE_USER")) {
                    // line 42
                    echo "\t\t\t\t\t\t\t\t\tUtilisateur
\t\t\t\t\t\t\t\t";
                } elseif ((                // line 43
$context["role"] == "ROLE_ADMIN")) {
                    // line 44
                    echo "\t\t\t\t\t\t\t\t\tAdministrateur
\t\t\t\t\t\t\t\t";
                }
                // line 46
                echo "\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 47
            echo "\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['u'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "\t\t\t</tbody>
\t\t</table>


\t</body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "user/download.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  141 => 50,  133 => 47,  127 => 46,  123 => 44,  121 => 43,  118 => 42,  115 => 41,  111 => 40,  106 => 37,  102 => 35,  98 => 33,  96 => 32,  91 => 30,  87 => 29,  83 => 28,  79 => 27,  75 => 26,  72 => 25,  68 => 24,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html>
\t<head>
\t\t<meta charset=\"UTF-8\">
\t\t<title>Tableau des Utilisateurs</title>
\t</head>
\t<body>
\t\t<h1 style=\"text-align: center; color: red\">Cuisinet Services</h1>
\t\t<h2 style=\"text-align: center\">Tableau des Utilisateurs</h2>

\t\t<table border=\"1\">
\t\t\t<thead>
\t\t\t\t<tr>
\t\t\t\t\t<th>ID</th>
\t\t\t\t\t<th>Username</th>
\t\t\t\t\t<th>Nom</th>
\t\t\t\t\t<th>Prenom</th>
\t\t\t\t\t<th>Email</th>
\t\t\t\t\t<th>Statut</th>
\t\t\t\t\t<th>Role</th>
\t\t\t\t</tr>
\t\t\t</thead>
\t\t\t<tbody>
\t\t\t\t{% for u in users %}
\t\t\t\t\t<tr>
\t\t\t\t\t\t<td>{{ u.id }}</td>
\t\t\t\t\t\t<td>{{ u.username }}</td>
\t\t\t\t\t\t<td>{{ u.nom }}</td>
\t\t\t\t\t\t<td>{{ u.prenom }}</td>
\t\t\t\t\t\t<td>{{ u.email }}</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t{% if u.isBanned == 1 %}
\t\t\t\t\t\t\t\t<span class=\"badge badge-danger\">Banni</span>
\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t<span class=\"badge badge-success\">Actif</span>
\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t</td>
\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t{% for role in u.roles %}
\t\t\t\t\t\t\t\t{% if role == \"ROLE_USER\" %}
\t\t\t\t\t\t\t\t\tUtilisateur
\t\t\t\t\t\t\t\t{% elseif role == \"ROLE_ADMIN\" %}
\t\t\t\t\t\t\t\t\tAdministrateur
\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t</td>
\t\t\t\t\t</tr>
\t\t\t\t{% endfor %}
\t\t\t</tbody>
\t\t</table>


\t</body>
</html>
", "user/download.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\user\\download.html.twig");
    }
}
