<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* agence/Show.html.twig */
class __TwigTemplate_76d84d6d479d6cba7b7d4ce9509c59365e681a24a422ea9f9fbbc076bfbc308f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'activeHebergements' => [$this, 'block_activeHebergements'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "agence/Show.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "agence/Show.html.twig"));

        $this->parent = $this->loadTemplate("base-front.html.twig", "agence/Show.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_activeHebergements($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeHebergements"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeHebergements"));

        // line 4
        echo "    class=active
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 8
        echo "    <div class=innerbannerwrap>
        <div class=content></div>
        <div   class=innerbanner><h2 class=bannerHeadline><span>    ";
        // line 10
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["a"]) || array_key_exists("a", $context) ? $context["a"] : (function () { throw new RuntimeError('Variable "a" does not exist.', 10, $this->source); })()), "nom", [], "any", false, false, false, 10), "html", null, true);
        echo "   </span> </h2></div>
    </div>

    <section class=\"matchSchedule countryclub\">
        <div class=container>
            <div class=row><h2 class=\"heading small\">Agence <span>Description</span></h2>

                <p class=headParagraph>Accommodation will be a key part of your time in Qatar and a broad range of options will be ready to host you in 2022. 
                    This includes hotels, apartments and villas, as well as Fan Village desert camping and rooms aboard cruise ships. Whether you stay in downtown Doha, at an urban island residence or by the incredible beaches,
                     everything is within easy reach. You’ll even have the possibility to attend more than one match a day during the group stage as all our stadiums are only a short distance away from one another, with no need to change accommodation throughout the tournament.

                    Accommodation sales will commence soon. Qatar looks forward to welcoming you to a land where the old blends seamlessly with the new, where nature meets the city and where pristine waters lap desert sands..</p></div>
        </div>
    </section>
    <section class=players>
        <div class=container>
            <div class=row><h2 class=heading>List Of <span> Accommodations </span></h2>
                <p class=headParagraph>Qatar has something for everyone with its vast range of hotels and world-renowned hospitality. Most of the hotels are located in the capital Doha but there are several out-of-town retreats for visitors looking for something different.</p>

                    <div class=\"wrapplayer clearfix\"><a class=\"prv prev-player\"></a> <a class=\"nxt next-player\"></a>
                        <ul class=\"boardmember clearfix\">
                            ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["hebergement"]) || array_key_exists("hebergement", $context) ? $context["hebergement"] : (function () { throw new RuntimeError('Variable "hebergement" does not exist.', 31, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["h"]) {
            // line 32
            echo "
                            <li class=clearfix>
                                <div>
                                    <div>
                                        <div class=fig01>
                                            <div class=memberimg
                                                 style=background:url(\"";
            // line 38
            echo twig_escape_filter($this->env, ($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/images/") . twig_get_attribute($this->env, $this->source, $context["h"], "photoH", [], "any", false, false, false, 38)), "html", null, true);
            echo " \") no-repeat top center></div>
                    
                                        </div>
                                        

                                        <div class=\"bg-black01 fig02\">
                                            <h6 class=paragraph02>";
            // line 44
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["h"], "nomH", [], "any", false, false, false, 44), "html", null, true);
            echo " </h6>
                    
                                           <div class=\"uppercaseheading red\"> ";
            // line 46
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["h"], "type", [], "any", false, false, false, 46), "html", null, true);
            echo " </div>   

                    
                                            <p>The FIFA World Cup Qatar 2022™ is less than a year away. Your host country, Qatar, offers an exciting range of accommodation – available to book soon..</p></div>
                                        <div class=\"bg-black fig02\"><p>Experience a FIFA World Cup™
                                            like no other.</p>
                                        </div>
                                        <div class=\"bg-redcolor fig02\"><p>Adresse : ";
            // line 53
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["h"], "adresse", [], "any", false, false, false, 53), "html", null, true);
            echo "</p></div>

                                    </div>
                                </div>

                                <a style=\"margin-top: 7px; text-align: center; margin-left: 55px\"  href=\"";
            // line 58
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AddByHebergement", ["id" => twig_get_attribute($this->env, $this->source, $context["h"], "id", [], "any", false, false, false, 58)]), "html", null, true);
            echo "\"class=\"btn btn-red\"> Je Reserve</a>

                            </li>

                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['h'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 63
        echo "
                        </ul>
                    </div>

            </div>
        </div>
    </section>
    <section class=\"map_wrapper clearfix\">
        <div id=map-section></div>
    <script type=text/javascript>
        \$(function () {
            \$('#da_gallery .gallery-list ').hoverdir();
        });
    </script>
    <script src=js/vendor/vendor.js></script>
    <script src=js/main.js></script>
    <script src=\"https://maps.googleapis.com/maps/api/js?v=3.exp\"></script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "agence/Show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  173 => 63,  162 => 58,  154 => 53,  144 => 46,  139 => 44,  130 => 38,  122 => 32,  118 => 31,  94 => 10,  90 => 8,  80 => 7,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front.html.twig' %}

{% block activeHebergements %}
    class=active
{% endblock %}

{% block content %}
    <div class=innerbannerwrap>
        <div class=content></div>
        <div   class=innerbanner><h2 class=bannerHeadline><span>    {{ a.nom }}   </span> </h2></div>
    </div>

    <section class=\"matchSchedule countryclub\">
        <div class=container>
            <div class=row><h2 class=\"heading small\">Agence <span>Description</span></h2>

                <p class=headParagraph>Accommodation will be a key part of your time in Qatar and a broad range of options will be ready to host you in 2022. 
                    This includes hotels, apartments and villas, as well as Fan Village desert camping and rooms aboard cruise ships. Whether you stay in downtown Doha, at an urban island residence or by the incredible beaches,
                     everything is within easy reach. You’ll even have the possibility to attend more than one match a day during the group stage as all our stadiums are only a short distance away from one another, with no need to change accommodation throughout the tournament.

                    Accommodation sales will commence soon. Qatar looks forward to welcoming you to a land where the old blends seamlessly with the new, where nature meets the city and where pristine waters lap desert sands..</p></div>
        </div>
    </section>
    <section class=players>
        <div class=container>
            <div class=row><h2 class=heading>List Of <span> Accommodations </span></h2>
                <p class=headParagraph>Qatar has something for everyone with its vast range of hotels and world-renowned hospitality. Most of the hotels are located in the capital Doha but there are several out-of-town retreats for visitors looking for something different.</p>

                    <div class=\"wrapplayer clearfix\"><a class=\"prv prev-player\"></a> <a class=\"nxt next-player\"></a>
                        <ul class=\"boardmember clearfix\">
                            {% for h in hebergement %}

                            <li class=clearfix>
                                <div>
                                    <div>
                                        <div class=fig01>
                                            <div class=memberimg
                                                 style=background:url(\"{{ asset('uploads/images/') ~ h.photoH }} \") no-repeat top center></div>
                    
                                        </div>
                                        

                                        <div class=\"bg-black01 fig02\">
                                            <h6 class=paragraph02>{{ h.nomH }} </h6>
                    
                                           <div class=\"uppercaseheading red\"> {{ h.type }} </div>   

                    
                                            <p>The FIFA World Cup Qatar 2022™ is less than a year away. Your host country, Qatar, offers an exciting range of accommodation – available to book soon..</p></div>
                                        <div class=\"bg-black fig02\"><p>Experience a FIFA World Cup™
                                            like no other.</p>
                                        </div>
                                        <div class=\"bg-redcolor fig02\"><p>Adresse : {{ h.adresse }}</p></div>

                                    </div>
                                </div>

                                <a style=\"margin-top: 7px; text-align: center; margin-left: 55px\"  href=\"{{ path('AddByHebergement',{'id':h.id}) }}\"class=\"btn btn-red\"> Je Reserve</a>

                            </li>

                            {% endfor %}

                        </ul>
                    </div>

            </div>
        </div>
    </section>
    <section class=\"map_wrapper clearfix\">
        <div id=map-section></div>
    <script type=text/javascript>
        \$(function () {
            \$('#da_gallery .gallery-list ').hoverdir();
        });
    </script>
    <script src=js/vendor/vendor.js></script>
    <script src=js/main.js></script>
    <script src=\"https://maps.googleapis.com/maps/api/js?v=3.exp\"></script>
{% endblock %}

", "agence/Show.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\agence\\Show.html.twig");
    }
}
