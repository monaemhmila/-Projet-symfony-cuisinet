<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* front/resetPassword/request.html.twig */
class __TwigTemplate_302648ba260e066c750f65e90afa960d3f5478cffe235e04572525e2c6a81d77 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/resetPassword/request.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/resetPassword/request.html.twig"));

        $this->parent = $this->loadTemplate("base-front2.html.twig", "front/resetPassword/request.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "
\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t<div class=\"overlay\"></div>
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t<h1 class=\"mb-2 bread\">User</h1>
\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t<a href=\"index.html\">User
\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span>Mot de passe oublié
\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t</span>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>
    <section class=innerpage  style=\"margin-top: 5rem; margin-bottom: 5rem;\">
        <div class=container>
            <div class=row><h2 class=heading>RÉINITIALISER VOTRE <span>MOT DE PASSE</span></h2>

                <p class=headParagraph></p>

                ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 31, $this->source); })()), "flashes", [0 => "reset_password_error"], "method", false, false, false, 31));
        foreach ($context['_seq'] as $context["_key"] => $context["flashError"]) {
            // line 32
            echo "                    <div class=\"alert alert-danger\" role=\"alert\">";
            echo twig_escape_filter($this->env, $context["flashError"], "html", null, true);
            echo "</div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashError'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "
                ";
        // line 35
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["requestForm"]) || array_key_exists("requestForm", $context) ? $context["requestForm"] : (function () { throw new RuntimeError('Variable "requestForm" does not exist.', 35, $this->source); })()), 'form_start', ["attr" => ["novalidate" => "novalidate"]]);
        echo "
                    ";
        // line 36
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["requestForm"]) || array_key_exists("requestForm", $context) ? $context["requestForm"] : (function () { throw new RuntimeError('Variable "requestForm" does not exist.', 36, $this->source); })()), "email", [], "any", false, false, false, 36), 'label');
        echo "
                    <input style=\"height: 60px\" ";
        // line 37
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["requestForm"]) || array_key_exists("requestForm", $context) ? $context["requestForm"] : (function () { throw new RuntimeError('Variable "requestForm" does not exist.', 37, $this->source); })()), "email", [], "any", false, false, false, 37), 'widget');
        echo "

                    <h5 style=\"margin: 15px 0px\">Entrez votre adresse e-mail et nous vous enverrons un lien pour réinitialiser votre mot de passe.</h5>

                    <button class=\"btn btn-primary\">Envoyer</button>

                ";
        // line 43
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["requestForm"]) || array_key_exists("requestForm", $context) ? $context["requestForm"] : (function () { throw new RuntimeError('Variable "requestForm" does not exist.', 43, $this->source); })()), 'form_end');
        echo "


            </div>


        </div>
        </div>
    </section>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "front/resetPassword/request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 43,  121 => 37,  117 => 36,  113 => 35,  110 => 34,  101 => 32,  97 => 31,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front2.html.twig' %}

{% block content %}

\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t<div class=\"overlay\"></div>
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t<h1 class=\"mb-2 bread\">User</h1>
\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t<a href=\"index.html\">User
\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span>Mot de passe oublié
\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t</span>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>
    <section class=innerpage  style=\"margin-top: 5rem; margin-bottom: 5rem;\">
        <div class=container>
            <div class=row><h2 class=heading>RÉINITIALISER VOTRE <span>MOT DE PASSE</span></h2>

                <p class=headParagraph></p>

                {% for flashError in app.flashes('reset_password_error') %}
                    <div class=\"alert alert-danger\" role=\"alert\">{{ flashError }}</div>
                {% endfor %}

                {{ form_start(requestForm,{'attr': {'novalidate': 'novalidate'}} ) }}
                    {{ form_label(requestForm.email) }}
                    <input style=\"height: 60px\" {{ form_widget(requestForm.email) }}

                    <h5 style=\"margin: 15px 0px\">Entrez votre adresse e-mail et nous vous enverrons un lien pour réinitialiser votre mot de passe.</h5>

                    <button class=\"btn btn-primary\">Envoyer</button>

                {{ form_end(requestForm) }}


            </div>


        </div>
        </div>
    </section>


{% endblock %}
", "front/resetPassword/request.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\front\\resetPassword\\request.html.twig");
    }
}
