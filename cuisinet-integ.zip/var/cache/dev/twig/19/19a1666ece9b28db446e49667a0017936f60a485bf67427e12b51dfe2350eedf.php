<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base-front2.html.twig */
class __TwigTemplate_7329c3b3cc88cfaee99ddc670570dd2af18659ceff87e052046282443f6f68a0 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'css' => [$this, 'block_css'],
            'body' => [$this, 'block_body'],
            'content' => [$this, 'block_content'],
            'js' => [$this, 'block_js'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base-front2.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base-front2.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
\t<head>
\t\t<title>
\t\t\t";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        // line 7
        echo "\t\t</title>
\t\t<meta charset=\"utf-8\">
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">

\t\t<link href=\"https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap\" rel=\"stylesheet\">
\t\t<link href=\"https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400;500;600;700&display=swap\" rel=\"stylesheet\">

\t\t<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">


\t\t";
        // line 17
        $this->displayBlock('css', $context, $blocks);
        // line 37
        echo "\t</head>

\t<body>
\t\t";
        // line 40
        $this->displayBlock('body', $context, $blocks);
        // line 252
        echo "\t</body>
</html>
";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Cuisinet
\t\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 17
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        // line 18
        echo "\t\t\t<link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/css/animate.css"), "html", null, true);
        echo "\">

\t\t\t<link rel=\"stylesheet\" href=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/css/owl.carousel.min.css"), "html", null, true);
        echo "\">
\t\t\t<link rel=\"stylesheet\" href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/css/owl.theme.default.min.css"), "html", null, true);
        echo "\">
\t\t\t<link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/css/magnific-popup.css"), "html", null, true);
        echo "\">

\t\t\t<link rel=\"stylesheet\" href=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/css/bootstrap-datepicker.css"), "html", null, true);
        echo "\">
\t\t\t<link rel=\"stylesheet\" href=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/css/jquery.timepicker.css"), "html", null, true);
        echo "\">


\t\t\t<link rel=\"stylesheet\" href=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/css/flaticon.css"), "html", null, true);
        echo "\">
\t\t\t<link rel=\"stylesheet\" href=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/css/style.css"), "html", null, true);
        echo "\">


\t\t\t<link rel=\"stylesheet\" href=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/mercuryseriesflashy/css/flashy.css"), "html", null, true);
        echo "\">
\t\t\t<link href=\"//fonts.googleapis.com/icon?family=Material+Icons\" rel=\"stylesheet\">
\t\t\t<link href='//fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700' rel='stylesheet'>
\t\t\t<script src=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/mercuryseriesflashy/js/flashy.js"), "html", null, true);
        echo "\"></script>
\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 40
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 41
        echo "
\t\t\t<div class=\"wrap\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"row justify-content-between\">
\t\t\t\t\t\t<div class=\"col-12 col-md d-flex align-items-center\">
\t\t\t\t\t\t\t<p class=\"mb-0 phone\">
\t\t\t\t\t\t\t\t<span class=\"mailus\">Phone no:</span>
\t\t\t\t\t\t\t\t<a href=\"#\">+00 1234 567</a>
\t\t\t\t\t\t\t\tor
\t\t\t\t\t\t\t\t<span class=\"mailus\">email us:</span>
\t\t\t\t\t\t\t\t<a href=\"#\">emailsample@email.com</a>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-12 col-md d-flex justify-content-md-end\">
\t\t\t\t\t\t\t<p class=\"mb-0\">Mon - Fri / 9:00-21:00, Sat - Sun / 10:00-20:00</p>
\t\t\t\t\t\t\t<div class=\"social-media\">
\t\t\t\t\t\t\t\t<p class=\"mb-0 d-flex\">
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"d-flex align-items-center justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-facebook\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"sr-only\">Facebook</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"d-flex align-items-center justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-twitter\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"sr-only\">Twitter</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"d-flex align-items-center justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-instagram\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"sr-only\">Instagram</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"d-flex align-items-center justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-dribbble\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"sr-only\">Dribbble</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>

\t\t\t<nav class=\"navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light\" id=\"ftco-navbar\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<a class=\"navbar-brand\" href=\"\">Cuisi.<span>net</span>
\t\t\t\t\t</a>
\t\t\t\t\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#ftco-nav\" aria-controls=\"ftco-nav\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
\t\t\t\t\t\t<span class=\"oi oi-menu\"></span>
\t\t\t\t\t\tMenu
\t\t\t\t\t</button>

\t\t\t\t\t<div class=\"collapse navbar-collapse\" id=\"ftco-nav\">
\t\t\t\t\t\t<ul class=\"navbar-nav ml-auto\">
\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t<a href=\"";
        // line 97
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo " \" class=\"nav-link\">Accueil</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t<a href=\" ";
        // line 100
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherfournisseurFront");
        echo " \" class=\"nav-link\">Fournisseurs</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t<a href=\"\" class=\"nav-link\">Produits</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</nav>
\t\t\t<!-- END nav -->

\t\t\t";
        // line 111
        $this->displayBlock('content', $context, $blocks);
        // line 112
        echo "
\t\t\t<footer class=\"ftco-footer ftco-no-pb ftco-section\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"row mb-5\">
\t\t\t\t\t\t<div class=\"col-md-6 col-lg-3\">
\t\t\t\t\t\t\t<div class=\"ftco-footer-widget mb-4\">
\t\t\t\t\t\t\t\t<h2 class=\"ftco-heading-2\">Cuisi.net</h2>
\t\t\t\t\t\t\t\t<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove</p>
\t\t\t\t\t\t\t\t<ul class=\"ftco-footer-social list-unstyled float-md-left float-lft mt-3\">
\t\t\t\t\t\t\t\t\t<li class=\"ftco-animate\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-twitter\"></span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"ftco-animate\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-facebook\"></span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"ftco-animate\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-instagram\"></span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6 col-lg-3\">
\t\t\t\t\t\t\t<div class=\"ftco-footer-widget mb-4\">
\t\t\t\t\t\t\t\t<h2 class=\"ftco-heading-2\">Open Hours</h2>
\t\t\t\t\t\t\t\t<ul class=\"list-unstyled open-hours\">
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Monday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 24:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Tuesday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 24:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Wednesday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 24:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Thursday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 24:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Friday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 02:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Saturday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 02:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Sunday</span>
\t\t\t\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t\t\t\tClosed</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6 col-lg-3\">
\t\t\t\t\t\t\t<div class=\"ftco-footer-widget mb-4\">
\t\t\t\t\t\t\t\t<h2 class=\"ftco-heading-2\">Instagram</h2>
\t\t\t\t\t\t\t\t<div class=\"thumb d-sm-flex\">
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( ";
        // line 179
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/images/insta-1.jpg"), "html", null, true);
        echo " );\"></a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( ";
        // line 180
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/images/insta-2.jpg"), "html", null, true);
        echo " );\"></a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( ";
        // line 181
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/images/insta-3.jpg"), "html", null, true);
        echo " );\"></a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"thumb d-flex\">
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( ";
        // line 184
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/images/insta-4.jpg"), "html", null, true);
        echo " );\"></a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( ";
        // line 185
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/images/insta-5.jpg"), "html", null, true);
        echo " );\"></a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( ";
        // line 186
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/images/insta-6.jpg"), "html", null, true);
        echo " );\"></a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6 col-lg-3\">
\t\t\t\t\t\t\t<div class=\"ftco-footer-widget mb-4\">
\t\t\t\t\t\t\t\t<h2 class=\"ftco-heading-2\">Newsletter</h2>
\t\t\t\t\t\t\t\t<p>Far far away, behind the word mountains, far from the countries.</p>
\t\t\t\t\t\t\t\t<form action=\"#\" class=\"subscribe-form\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control mb-2 text-center\" placeholder=\"Enter email address\">
\t\t\t\t\t\t\t\t\t\t<input type=\"submit\" value=\"Subscribe\" class=\"form-control submit px-3\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"container-fluid px-0 bg-primary py-3\">
\t\t\t\t\t<div class=\"row no-gutters\">
\t\t\t\t\t\t<div class=\"col-md-12 text-center\">

\t\t\t\t\t\t\t<p
\t\t\t\t\t\t\t\tclass=\"mb-0\">
\t\t\t\t\t\t\t\t<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
\t\t\t\t\t\t\t\tCopyright &copy;<script>
\t\t\t\t\t\t\t\t\tdocument.write(new Date().getFullYear());
\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t\tAll rights reserved | This template is made with
\t\t\t\t\t\t\t\t<i class=\"fa fa-heart\" aria-hidden=\"true\"></i>
\t\t\t\t\t\t\t\tby
\t\t\t\t\t\t\t\t<a href=\"https://colorlib.com\" target=\"_blank\">Colorlib</a>
\t\t\t\t\t\t\t\t<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</footer>


\t\t\t<!-- loader -->
\t\t\t<div id=\"ftco-loader\" class=\"show fullscreen\">
\t\t\t\t<svg class=\"circular\" width=\"48px\" height=\"48px\"><circle class=\"path-bg\" cx=\"24\" cy=\"24\" r=\"22\" fill=\"none\" stroke-width=\"4\" stroke=\"#eeeeee\"/><circle class=\"path\" cx=\"24\" cy=\"24\" r=\"22\" fill=\"none\" stroke-width=\"4\" stroke-miterlimit=\"10\" stroke=\"#F96D00\"/></svg>
\t\t\t</div>

\t\t\t";
        // line 231
        $this->displayBlock('js', $context, $blocks);
        // line 249
        echo "

\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 111
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 231
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 232
        echo "\t\t\t\t<script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 233
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/jquery-migrate-3.0.1.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 234
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/popper.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 235
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/bootstrap.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 236
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/jquery.easing.1.3.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 237
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/jquery.waypoints.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 238
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/jquery.stellar.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 239
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/owl.carousel.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 240
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/jquery.magnific-popup.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 241
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/jquery.animateNumber.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 242
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/bootstrap-datepicker.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 243
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/jquery.timepicker.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 244
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/scrollax.min.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false\"></script>
\t\t\t\t<script src=\"";
        // line 246
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/google-map.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t<script src=\"";
        // line 247
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office-v2/js/main.js"), "html", null, true);
        echo "\"></script>
\t\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base-front2.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  505 => 247,  501 => 246,  496 => 244,  492 => 243,  488 => 242,  484 => 241,  480 => 240,  476 => 239,  472 => 238,  468 => 237,  464 => 236,  460 => 235,  456 => 234,  452 => 233,  447 => 232,  437 => 231,  419 => 111,  407 => 249,  405 => 231,  357 => 186,  353 => 185,  349 => 184,  343 => 181,  339 => 180,  335 => 179,  266 => 112,  264 => 111,  250 => 100,  244 => 97,  186 => 41,  176 => 40,  164 => 35,  158 => 32,  152 => 29,  148 => 28,  142 => 25,  138 => 24,  133 => 22,  129 => 21,  125 => 20,  119 => 18,  109 => 17,  89 => 5,  77 => 252,  75 => 40,  70 => 37,  68 => 17,  56 => 7,  54 => 5,  48 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
\t<head>
\t\t<title>
\t\t\t{% block title %}Cuisinet
\t\t\t{% endblock %}
\t\t</title>
\t\t<meta charset=\"utf-8\">
\t\t<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">

\t\t<link href=\"https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap\" rel=\"stylesheet\">
\t\t<link href=\"https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400;500;600;700&display=swap\" rel=\"stylesheet\">

\t\t<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css\">


\t\t{% block css %}
\t\t\t<link rel=\"stylesheet\" href=\"{{ asset ('front-office-v2/css/animate.css')}}\">

\t\t\t<link rel=\"stylesheet\" href=\"{{ asset ('front-office-v2/css/owl.carousel.min.css')}}\">
\t\t\t<link rel=\"stylesheet\" href=\"{{ asset ('front-office-v2/css/owl.theme.default.min.css')}}\">
\t\t\t<link rel=\"stylesheet\" href=\"{{ asset ('front-office-v2/css/magnific-popup.css')}}\">

\t\t\t<link rel=\"stylesheet\" href=\"{{ asset ('front-office-v2/css/bootstrap-datepicker.css')}}\">
\t\t\t<link rel=\"stylesheet\" href=\"{{ asset ('front-office-v2/css/jquery.timepicker.css')}}\">


\t\t\t<link rel=\"stylesheet\" href=\"{{ asset ('front-office-v2/css/flaticon.css')}}\">
\t\t\t<link rel=\"stylesheet\" href=\"{{ asset ('front-office-v2/css/style.css')}}\">


\t\t\t<link rel=\"stylesheet\" href=\"{{ asset('bundles/mercuryseriesflashy/css/flashy.css') }}\">
\t\t\t<link href=\"//fonts.googleapis.com/icon?family=Material+Icons\" rel=\"stylesheet\">
\t\t\t<link href='//fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700' rel='stylesheet'>
\t\t\t<script src=\"{{ asset('bundles/mercuryseriesflashy/js/flashy.js') }}\"></script>
\t\t{% endblock %}
\t</head>

\t<body>
\t\t{% block body %}

\t\t\t<div class=\"wrap\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"row justify-content-between\">
\t\t\t\t\t\t<div class=\"col-12 col-md d-flex align-items-center\">
\t\t\t\t\t\t\t<p class=\"mb-0 phone\">
\t\t\t\t\t\t\t\t<span class=\"mailus\">Phone no:</span>
\t\t\t\t\t\t\t\t<a href=\"#\">+00 1234 567</a>
\t\t\t\t\t\t\t\tor
\t\t\t\t\t\t\t\t<span class=\"mailus\">email us:</span>
\t\t\t\t\t\t\t\t<a href=\"#\">emailsample@email.com</a>
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-12 col-md d-flex justify-content-md-end\">
\t\t\t\t\t\t\t<p class=\"mb-0\">Mon - Fri / 9:00-21:00, Sat - Sun / 10:00-20:00</p>
\t\t\t\t\t\t\t<div class=\"social-media\">
\t\t\t\t\t\t\t\t<p class=\"mb-0 d-flex\">
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"d-flex align-items-center justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-facebook\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"sr-only\">Facebook</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"d-flex align-items-center justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-twitter\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"sr-only\">Twitter</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"d-flex align-items-center justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-instagram\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"sr-only\">Instagram</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"d-flex align-items-center justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-dribbble\">
\t\t\t\t\t\t\t\t\t\t\t<i class=\"sr-only\">Dribbble</i>
\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>

\t\t\t<nav class=\"navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light\" id=\"ftco-navbar\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<a class=\"navbar-brand\" href=\"\">Cuisi.<span>net</span>
\t\t\t\t\t</a>
\t\t\t\t\t<button class=\"navbar-toggler\" type=\"button\" data-toggle=\"collapse\" data-target=\"#ftco-nav\" aria-controls=\"ftco-nav\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
\t\t\t\t\t\t<span class=\"oi oi-menu\"></span>
\t\t\t\t\t\tMenu
\t\t\t\t\t</button>

\t\t\t\t\t<div class=\"collapse navbar-collapse\" id=\"ftco-nav\">
\t\t\t\t\t\t<ul class=\"navbar-nav ml-auto\">
\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t<a href=\"{{ path('home') }} \" class=\"nav-link\">Accueil</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t<a href=\" {{ path('AfficherfournisseurFront') }} \" class=\"nav-link\">Fournisseurs</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t<li class=\"nav-item\">
\t\t\t\t\t\t\t\t<a href=\"\" class=\"nav-link\">Produits</a>
\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t</ul>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</nav>
\t\t\t<!-- END nav -->

\t\t\t{% block content %}{% endblock %}

\t\t\t<footer class=\"ftco-footer ftco-no-pb ftco-section\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"row mb-5\">
\t\t\t\t\t\t<div class=\"col-md-6 col-lg-3\">
\t\t\t\t\t\t\t<div class=\"ftco-footer-widget mb-4\">
\t\t\t\t\t\t\t\t<h2 class=\"ftco-heading-2\">Cuisi.net</h2>
\t\t\t\t\t\t\t\t<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove</p>
\t\t\t\t\t\t\t\t<ul class=\"ftco-footer-social list-unstyled float-md-left float-lft mt-3\">
\t\t\t\t\t\t\t\t\t<li class=\"ftco-animate\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-twitter\"></span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"ftco-animate\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-facebook\"></span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"ftco-animate\">
\t\t\t\t\t\t\t\t\t\t<a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-instagram\"></span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6 col-lg-3\">
\t\t\t\t\t\t\t<div class=\"ftco-footer-widget mb-4\">
\t\t\t\t\t\t\t\t<h2 class=\"ftco-heading-2\">Open Hours</h2>
\t\t\t\t\t\t\t\t<ul class=\"list-unstyled open-hours\">
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Monday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 24:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Tuesday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 24:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Wednesday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 24:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Thursday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 24:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Friday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 02:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Saturday</span>
\t\t\t\t\t\t\t\t\t\t<span>9:00 - 02:00</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t\t<li class=\"d-flex\">
\t\t\t\t\t\t\t\t\t\t<span>Sunday</span>
\t\t\t\t\t\t\t\t\t\t<span>
\t\t\t\t\t\t\t\t\t\t\tClosed</span>
\t\t\t\t\t\t\t\t\t</li>
\t\t\t\t\t\t\t\t</ul>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6 col-lg-3\">
\t\t\t\t\t\t\t<div class=\"ftco-footer-widget mb-4\">
\t\t\t\t\t\t\t\t<h2 class=\"ftco-heading-2\">Instagram</h2>
\t\t\t\t\t\t\t\t<div class=\"thumb d-sm-flex\">
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( {{ asset ('front-office-v2/images/insta-1.jpg')}} );\"></a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( {{ asset ('front-office-v2/images/insta-2.jpg')}} );\"></a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( {{ asset ('front-office-v2/images/insta-3.jpg')}} );\"></a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"thumb d-flex\">
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( {{ asset ('front-office-v2/images/insta-4.jpg')}} );\"></a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( {{ asset ('front-office-v2/images/insta-5.jpg')}} );\"></a>
\t\t\t\t\t\t\t\t\t<a href=\"#\" class=\"thumb-menu img\" style=\"background-image: url( {{ asset ('front-office-v2/images/insta-6.jpg')}} );\"></a>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-6 col-lg-3\">
\t\t\t\t\t\t\t<div class=\"ftco-footer-widget mb-4\">
\t\t\t\t\t\t\t\t<h2 class=\"ftco-heading-2\">Newsletter</h2>
\t\t\t\t\t\t\t\t<p>Far far away, behind the word mountains, far from the countries.</p>
\t\t\t\t\t\t\t\t<form action=\"#\" class=\"subscribe-form\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control mb-2 text-center\" placeholder=\"Enter email address\">
\t\t\t\t\t\t\t\t\t\t<input type=\"submit\" value=\"Subscribe\" class=\"form-control submit px-3\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"container-fluid px-0 bg-primary py-3\">
\t\t\t\t\t<div class=\"row no-gutters\">
\t\t\t\t\t\t<div class=\"col-md-12 text-center\">

\t\t\t\t\t\t\t<p
\t\t\t\t\t\t\t\tclass=\"mb-0\">
\t\t\t\t\t\t\t\t<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
\t\t\t\t\t\t\t\tCopyright &copy;<script>
\t\t\t\t\t\t\t\t\tdocument.write(new Date().getFullYear());
\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t\tAll rights reserved | This template is made with
\t\t\t\t\t\t\t\t<i class=\"fa fa-heart\" aria-hidden=\"true\"></i>
\t\t\t\t\t\t\t\tby
\t\t\t\t\t\t\t\t<a href=\"https://colorlib.com\" target=\"_blank\">Colorlib</a>
\t\t\t\t\t\t\t\t<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</footer>


\t\t\t<!-- loader -->
\t\t\t<div id=\"ftco-loader\" class=\"show fullscreen\">
\t\t\t\t<svg class=\"circular\" width=\"48px\" height=\"48px\"><circle class=\"path-bg\" cx=\"24\" cy=\"24\" r=\"22\" fill=\"none\" stroke-width=\"4\" stroke=\"#eeeeee\"/><circle class=\"path\" cx=\"24\" cy=\"24\" r=\"22\" fill=\"none\" stroke-width=\"4\" stroke-miterlimit=\"10\" stroke=\"#F96D00\"/></svg>
\t\t\t</div>

\t\t\t{% block js %}
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/jquery.min.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/jquery-migrate-3.0.1.min.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/popper.min.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/bootstrap.min.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/jquery.easing.1.3.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/jquery.waypoints.min.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/jquery.stellar.min.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/owl.carousel.min.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/jquery.magnific-popup.min.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/jquery.animateNumber.min.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/bootstrap-datepicker.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/jquery.timepicker.min.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/scrollax.min.js')}}\"></script>
\t\t\t\t<script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/google-map.js')}}\"></script>
\t\t\t\t<script src=\"{{ asset ('front-office-v2/js/main.js')}}\"></script>
\t\t\t{% endblock %}


\t\t{% endblock %}
\t</body>
</html>
", "base-front2.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\base-front2.html.twig");
    }
}
