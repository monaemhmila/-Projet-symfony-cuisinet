<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* user/afficher.html.twig */
class __TwigTemplate_09d1b9010e31e17b84fe0b76ce1fae2b9bfc951b65a670b0f9fd12d86bb139ea extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'user' => [$this, 'block_user'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-back.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/afficher.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "user/afficher.html.twig"));

        $this->parent = $this->loadTemplate("base-back.html.twig", "user/afficher.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_user($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        // line 4
        echo "\t";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 4, $this->source); })()), "user", [], "any", false, false, false, 4), "username", [], "any", false, false, false, 4), "html", null, true);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 9
        echo "
\t<!-- start page title -->
\t<div class=\"row\">
\t\t<div class=\"col-12\">
\t\t\t<div
\t\t\t\tclass=\"page-title-box d-flex align-items-center justify-content-between\">
\t\t\t\t<!--<h4 class=\"mb-0\">Responsive Table</h4>-->

\t\t\t\t<div class=\"page-title-right\">
\t\t\t\t\t<ol class=\"breadcrumb m-0\">
\t\t\t\t\t\t<li class=\"breadcrumb-item\">
\t\t\t\t\t\t\t<a href=\"javascript: void(0);\">Utilisateur</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"breadcrumb-item active\">Afficher</li>
\t\t\t\t\t</ol>
\t\t\t\t</div>

\t\t\t</div>
\t\t</div>
\t</div>
\t<!-- end page title -->

\t<!-- start row -->
\t<div class=\"row\">
\t\t<div class=\"col-12\">
\t\t\t<div class=\"card\">
\t\t\t\t<div class=\"card-body\">

\t\t\t\t\t<h4 class=\"card-title\">Tableau des Utilisateurs</h4>
\t\t\t\t\t<a href=\"";
        // line 38
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("DownloadUsersData");
        echo "\" class=\"btn btn-dark waves-effect waves-light\">Download PDF</a>
\t\t\t\t\t<p class=\"card-title-desc\"></p>

\t\t\t\t\t<div class=\"table-rep-plugin\">
\t\t\t\t\t\t<div class=\"table-responsive mb-0\" data-pattern=\"priority-columns\">
\t\t\t\t\t\t\t<table id=\"tech-companies-1\" class=\"table\">
\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<th>ID</th>
\t\t\t\t\t\t\t\t\t\t<th>Username</th>
\t\t\t\t\t\t\t\t\t\t<th>Nom</th>
\t\t\t\t\t\t\t\t\t\t<th>Prenom</th>
\t\t\t\t\t\t\t\t\t\t<th>Email</th>
\t\t\t\t\t\t\t\t\t\t<th>Role</th>
\t\t\t\t\t\t\t\t\t\t<th>Statut</th>
\t\t\t\t\t\t\t\t\t\t<th style=\"width: 120px;\">Action</th>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t<tr ";
        // line 57
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["users"]) || array_key_exists("users", $context) ? $context["users"] : (function () { throw new RuntimeError('Variable "users" does not exist.', 57, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["u"]) {
            echo ">
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 58
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["u"], "id", [], "any", false, false, false, 58), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 59
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["u"], "username", [], "any", false, false, false, 59), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 60
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["u"], "nom", [], "any", false, false, false, 60), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 61
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["u"], "prenom", [], "any", false, false, false, 61), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>";
            // line 62
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["u"], "email", [], "any", false, false, false, 62), "html", null, true);
            echo "</td>
\t\t\t\t\t\t\t\t\t\t<td>

\t\t\t\t\t\t\t\t\t\t\t";
            // line 65
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["u"], "roles", [], "any", false, false, false, 65));
            foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
                // line 66
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
                if (($context["role"] == "ROLE_USER")) {
                    // line 67
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\tUtilisateur
\t\t\t\t\t\t\t\t\t\t\t\t";
                } elseif ((                // line 68
$context["role"] == "ROLE_ADMIN")) {
                    // line 69
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\tAdministrateur
\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                // line 71
                echo "\t\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 72
            echo "
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t";
            // line 75
            if ((twig_get_attribute($this->env, $this->source, $context["u"], "isBanned", [], "any", false, false, false, 75) == 1)) {
                // line 76
                echo "                                                <span class=\"badge badge-danger\">Banni</span>
                                            ";
            } else {
                // line 78
                echo "                                                <span class=\"badge badge-success\">Actif</span>
                                            ";
            }
            // line 80
            echo "
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 83
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ModifierUser", ["id" => twig_get_attribute($this->env, $this->source, $context["u"], "id", [], "any", false, false, false, 83)]), "html", null, true);
            echo "\" class=\"mr-3 text-primary\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Modifier\" data-original-title=\"Edit\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mdi mdi-pencil font-size-18\"></i>
\t\t\t\t\t\t\t\t\t\t\t</a>
                                            ";
            // line 86
            if ((twig_get_attribute($this->env, $this->source, $context["u"], "isBanned", [], "any", false, false, false, 86) == 1)) {
                // line 87
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("UnbanUser", ["id" => twig_get_attribute($this->env, $this->source, $context["u"], "id", [], "any", false, false, false, 87)]), "html", null, true);
                echo "\" class=\"text-success\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Autoriser l'acces\" data-original-title=\"Unban\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mdi mdi-account-cancel-outline font-size-18\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 91
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("BanUser", ["id" => twig_get_attribute($this->env, $this->source, $context["u"], "id", [], "any", false, false, false, 91)]), "html", null, true);
                echo "\" class=\"text-danger\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Bannir\" data-original-title=\"Ban\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mdi mdi-account-cancel-outline font-size-18\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 95
            echo "\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("SupprimerUser", ["id" => twig_get_attribute($this->env, $this->source, $context["u"], "id", [], "any", false, false, false, 95)]), "html", null, true);
            echo "\" class=\"text-danger\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Supprimer\" data-original-title=\"Delete\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mdi mdi-trash-can font-size-18\"></i>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr> ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['u'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 100
        echo "\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>

\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- end col -->
\t</div>
\t<!-- end row -->

\t<script>
\t\t\$('#tech-companies-1').DataTable();
\t</script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "user/afficher.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  251 => 100,  239 => 95,  231 => 91,  223 => 87,  221 => 86,  215 => 83,  210 => 80,  206 => 78,  202 => 76,  200 => 75,  195 => 72,  189 => 71,  185 => 69,  183 => 68,  180 => 67,  177 => 66,  173 => 65,  167 => 62,  163 => 61,  159 => 60,  155 => 59,  151 => 58,  145 => 57,  123 => 38,  92 => 9,  82 => 8,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-back.html.twig' %}

{% block user %}
\t{{ app.user.username }}
{% endblock %}


{% block content %}

\t<!-- start page title -->
\t<div class=\"row\">
\t\t<div class=\"col-12\">
\t\t\t<div
\t\t\t\tclass=\"page-title-box d-flex align-items-center justify-content-between\">
\t\t\t\t<!--<h4 class=\"mb-0\">Responsive Table</h4>-->

\t\t\t\t<div class=\"page-title-right\">
\t\t\t\t\t<ol class=\"breadcrumb m-0\">
\t\t\t\t\t\t<li class=\"breadcrumb-item\">
\t\t\t\t\t\t\t<a href=\"javascript: void(0);\">Utilisateur</a>
\t\t\t\t\t\t</li>
\t\t\t\t\t\t<li class=\"breadcrumb-item active\">Afficher</li>
\t\t\t\t\t</ol>
\t\t\t\t</div>

\t\t\t</div>
\t\t</div>
\t</div>
\t<!-- end page title -->

\t<!-- start row -->
\t<div class=\"row\">
\t\t<div class=\"col-12\">
\t\t\t<div class=\"card\">
\t\t\t\t<div class=\"card-body\">

\t\t\t\t\t<h4 class=\"card-title\">Tableau des Utilisateurs</h4>
\t\t\t\t\t<a href=\"{{ path('DownloadUsersData') }}\" class=\"btn btn-dark waves-effect waves-light\">Download PDF</a>
\t\t\t\t\t<p class=\"card-title-desc\"></p>

\t\t\t\t\t<div class=\"table-rep-plugin\">
\t\t\t\t\t\t<div class=\"table-responsive mb-0\" data-pattern=\"priority-columns\">
\t\t\t\t\t\t\t<table id=\"tech-companies-1\" class=\"table\">
\t\t\t\t\t\t\t\t<thead>
\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t<th>ID</th>
\t\t\t\t\t\t\t\t\t\t<th>Username</th>
\t\t\t\t\t\t\t\t\t\t<th>Nom</th>
\t\t\t\t\t\t\t\t\t\t<th>Prenom</th>
\t\t\t\t\t\t\t\t\t\t<th>Email</th>
\t\t\t\t\t\t\t\t\t\t<th>Role</th>
\t\t\t\t\t\t\t\t\t\t<th>Statut</th>
\t\t\t\t\t\t\t\t\t\t<th style=\"width: 120px;\">Action</th>
\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t</thead>
\t\t\t\t\t\t\t\t<tbody>
\t\t\t\t\t\t\t\t\t<tr {% for u in users %}>
\t\t\t\t\t\t\t\t\t\t<td>{{ u.id }}</td>
\t\t\t\t\t\t\t\t\t\t<td>{{ u.username }}</td>
\t\t\t\t\t\t\t\t\t\t<td>{{ u.nom }}</td>
\t\t\t\t\t\t\t\t\t\t<td>{{ u.prenom }}</td>
\t\t\t\t\t\t\t\t\t\t<td>{{ u.email }}</td>
\t\t\t\t\t\t\t\t\t\t<td>

\t\t\t\t\t\t\t\t\t\t\t{% for role in u.roles %}
\t\t\t\t\t\t\t\t\t\t\t\t{% if role == \"ROLE_USER\" %}
\t\t\t\t\t\t\t\t\t\t\t\t\tUtilisateur
\t\t\t\t\t\t\t\t\t\t\t\t{% elseif role == \"ROLE_ADMIN\" %}
\t\t\t\t\t\t\t\t\t\t\t\t\tAdministrateur
\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t{% endfor %}

\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t{% if u.isBanned == 1 %}
                                                <span class=\"badge badge-danger\">Banni</span>
                                            {% else %}
                                                <span class=\"badge badge-success\">Actif</span>
                                            {% endif %}

\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t\t<td>
\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('ModifierUser',{'id':u.id}) }}\" class=\"mr-3 text-primary\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Modifier\" data-original-title=\"Edit\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mdi mdi-pencil font-size-18\"></i>
\t\t\t\t\t\t\t\t\t\t\t</a>
                                            {% if u.isBanned == 1 %}
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('UnbanUser',{'id':u.id}) }}\" class=\"text-success\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Autoriser l'acces\" data-original-title=\"Unban\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mdi mdi-account-cancel-outline font-size-18\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('BanUser',{'id':u.id}) }}\" class=\"text-danger\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Bannir\" data-original-title=\"Ban\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mdi mdi-account-cancel-outline font-size-18\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{ path('SupprimerUser',{'id':u.id}) }}\" class=\"text-danger\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"Supprimer\" data-original-title=\"Delete\">
\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"mdi mdi-trash-can font-size-18\"></i>
\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t</td>
\t\t\t\t\t\t\t\t\t</tr> {% endfor %}
\t\t\t\t\t\t\t\t</tbody>
\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t</div>

\t\t\t\t\t</div>

\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t\t<!-- end col -->
\t</div>
\t<!-- end row -->

\t<script>
\t\t\$('#tech-companies-1').DataTable();
\t</script>

{% endblock %}
", "user/afficher.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\user\\afficher.html.twig");
    }
}
