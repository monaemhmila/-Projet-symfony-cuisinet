<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* reservation/Affiche.html.twig */
class __TwigTemplate_42e815788c48e57eb3e5e95892440904c2f1438210a5d9f23044e196869902d8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'user' => [$this, 'block_user'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-back.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "reservation/Affiche.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "reservation/Affiche.html.twig"));

        $this->parent = $this->loadTemplate("base-back.html.twig", "reservation/Affiche.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_user($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        // line 3
        echo "    ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 3, $this->source); })()), "user", [], "any", false, false, false, 3), "username", [], "any", false, false, false, 3), "html", null, true);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 7
        echo "   <!-- start page title -->
   <div class=\"row\" style=\"width: 100%;\">
    <div class=\"col-12\">
        <div class=\"page-title-box d-flex align-items-center justify-content-between\">
            <!--<h4 class=\"mb-0\">Responsive Table</h4>-->

            <div class=\"page-title-right\">
                <ol class=\"breadcrumb m-0\">
                    <li class=\"breadcrumb-item\"><a href=\"javascript: void(0);\">Réservations</a></li>
                    <li class=\"breadcrumb-item active\">Afficher</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<!-- start row -->
<div class=\"row\" style=\"width: 100%;\">
    <div class=\"col-12\">
        <div class=\"card\">
            <div class=\"card-body\">
                <p class=\"card-title-desc\"></p>

                <h4 class=\"card-title\">Tableau Des Réservations</h4>
                <p class=\"card-title-desc\"></p>

                <div class=\"table-rep-plugin\">
                    <div class=\"table-responsive mb-0\" data-pattern=\"priority-columns\">
                        <table id=\"datatable-buttons\" class=\"table table-striped table-bordered dt-responsive nowrap\" style=\"border-collapse: collapse; border-spacing: 0; width: 100%;\">

                            <thead class=\"thead-light\">
                    <tr>
        <th>ID</th>
        <th>date debut</th>
        <th>date fin</th>
        <th>hebergement</th>
        <th>NomClient</th>
        <th>Actions</th>
        
    </tr>
</thead>

    <tr ";
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 51, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["r"]) {
            echo ">
        <td>";
            // line 52
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["r"], "id", [], "any", false, false, false, 52), "html", null, true);
            echo "</td>
        <td>";
            // line 53
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["r"], "dateDebut", [], "any", false, false, false, 53), "d-m-Y"), "html", null, true);
            echo "</td>
        <td>";
            // line 54
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, $context["r"], "dateFin", [], "any", false, false, false, 54), "d-m-Y"), "html", null, true);
            echo "</td>
        <td>";
            // line 55
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["r"], "hebergement", [], "any", false, false, false, 55), "NomH", [], "any", false, false, false, 55), "html", null, true);
            echo "</td>
        <td>";
            // line 56
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["r"], "user", [], "any", false, false, false, 56), "nom", [], "any", false, false, false, 56), "html", null, true);
            echo "</td>
        <td><a href=\"";
            // line 57
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("UpdateR", ["id" => twig_get_attribute($this->env, $this->source, $context["r"], "id", [], "any", false, false, false, 57)]), "html", null, true);
            echo "\"><i class=\"ri-pencil-fill\"></i></a>     <a href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("deleteR", ["id" => twig_get_attribute($this->env, $this->source, $context["r"], "id", [], "any", false, false, false, 57)]), "html", null, true);
            echo "\"><i class=\"ri-delete-bin-fill\"></i></a></td>



    </tr";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['r'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo ">

</tbody>


</tbody>
</table>
</div>

</div>

</div>
</div>
</div> <!-- end col -->
</div>
<!-- end row -->

<script>
\$('#datatable-buttons').DataTable();
</script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "reservation/Affiche.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 61,  164 => 57,  160 => 56,  156 => 55,  152 => 54,  148 => 53,  144 => 52,  138 => 51,  92 => 7,  82 => 6,  69 => 3,  59 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-back.html.twig' %}
{% block user %}
    {{ app.user.username }}
{% endblock %}

{% block content %}
   <!-- start page title -->
   <div class=\"row\" style=\"width: 100%;\">
    <div class=\"col-12\">
        <div class=\"page-title-box d-flex align-items-center justify-content-between\">
            <!--<h4 class=\"mb-0\">Responsive Table</h4>-->

            <div class=\"page-title-right\">
                <ol class=\"breadcrumb m-0\">
                    <li class=\"breadcrumb-item\"><a href=\"javascript: void(0);\">Réservations</a></li>
                    <li class=\"breadcrumb-item active\">Afficher</li>
                </ol>
            </div>

        </div>
    </div>
</div>
<!-- end page title -->

<!-- start row -->
<div class=\"row\" style=\"width: 100%;\">
    <div class=\"col-12\">
        <div class=\"card\">
            <div class=\"card-body\">
                <p class=\"card-title-desc\"></p>

                <h4 class=\"card-title\">Tableau Des Réservations</h4>
                <p class=\"card-title-desc\"></p>

                <div class=\"table-rep-plugin\">
                    <div class=\"table-responsive mb-0\" data-pattern=\"priority-columns\">
                        <table id=\"datatable-buttons\" class=\"table table-striped table-bordered dt-responsive nowrap\" style=\"border-collapse: collapse; border-spacing: 0; width: 100%;\">

                            <thead class=\"thead-light\">
                    <tr>
        <th>ID</th>
        <th>date debut</th>
        <th>date fin</th>
        <th>hebergement</th>
        <th>NomClient</th>
        <th>Actions</th>
        
    </tr>
</thead>

    <tr {% for r in reservation %}>
        <td>{{ r.id }}</td>
        <td>{{ r.dateDebut|date('d-m-Y') }}</td>
        <td>{{ r.dateFin|date('d-m-Y') }}</td>
        <td>{{ r.hebergement.NomH }}</td>
        <td>{{ r.user.nom }}</td>
        <td><a href=\"{{ path('UpdateR',{'id':r.id}) }}\"><i class=\"ri-pencil-fill\"></i></a>     <a href=\"{{ path('deleteR',{'id':r.id}) }}\"><i class=\"ri-delete-bin-fill\"></i></a></td>



    </tr{% endfor %}>

</tbody>


</tbody>
</table>
</div>

</div>

</div>
</div>
</div> <!-- end col -->
</div>
<!-- end row -->

<script>
\$('#datatable-buttons').DataTable();
</script>
{% endblock %}
", "reservation/Affiche.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\reservation\\Affiche.html.twig");
    }
}
