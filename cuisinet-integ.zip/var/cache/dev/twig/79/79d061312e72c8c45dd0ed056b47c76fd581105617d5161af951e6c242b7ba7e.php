<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* produit/statistiques.html.twig */
class __TwigTemplate_0786075e9e25eca234a569d45a484f599a3d856def6dc83a844962deada65e26 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'user' => [$this, 'block_user'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-back.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "produit/statistiques.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "produit/statistiques.html.twig"));

        $this->parent = $this->loadTemplate("base-back.html.twig", "produit/statistiques.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_user($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        // line 4
        echo "    ";
        echo twig_escape_filter($this->env, (isset($context["user"]) || array_key_exists("user", $context) ? $context["user"] : (function () { throw new RuntimeError('Variable "user" does not exist.', 4, $this->source); })()), "html", null, true);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 9
        echo "
    <div class=\"row\">
        <div class=\"col-lg-6\">
            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title mb-4\">Statistiques des Produits Par Rapport la Taille</h4>
                    <div id=\"pie_chart\" class=\"apex-charts\" dir=\"ltr\"></div>
                </div>
            </div>
        </div>
        <div class=\"col-lg-6\">
            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title mb-4\">Statistiques des Produits Par Rapport le Type</h4>

                    <div id=\"donut_chart\" class=\"apex-charts\"  dir=\"ltr\"></div>
                </div>
            </div>
        </div>
    </div>


    <script>
        ";
        // line 32
        $context["XS"] = 0;
        // line 33
        echo "        ";
        $context["S"] = 0;
        // line 34
        echo "        ";
        $context["M"] = 0;
        // line 35
        echo "        ";
        $context["L"] = 0;
        // line 36
        echo "        ";
        $context["XL"] = 0;
        // line 37
        echo "
        ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 38, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 39
            echo "
            ";
            // line 40
            if ((twig_get_attribute($this->env, $this->source, $context["p"], "taille", [], "any", false, false, false, 40) == "XS")) {
                // line 41
                echo "                ";
                $context["XS"] = ((isset($context["XS"]) || array_key_exists("XS", $context) ? $context["XS"] : (function () { throw new RuntimeError('Variable "XS" does not exist.', 41, $this->source); })()) + 1);
                // line 42
                echo "             ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "taille", [], "any", false, false, false, 42) == "S")) {
                // line 43
                echo "                ";
                $context["S"] = ((isset($context["S"]) || array_key_exists("S", $context) ? $context["S"] : (function () { throw new RuntimeError('Variable "S" does not exist.', 43, $this->source); })()) + 1);
                // line 44
                echo "            ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "taille", [], "any", false, false, false, 44) == "M")) {
                // line 45
                echo "                ";
                $context["M"] = ((isset($context["M"]) || array_key_exists("M", $context) ? $context["M"] : (function () { throw new RuntimeError('Variable "M" does not exist.', 45, $this->source); })()) + 1);
                // line 46
                echo "            ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "taille", [], "any", false, false, false, 46) == "L")) {
                // line 47
                echo "                ";
                $context["L"] = ((isset($context["L"]) || array_key_exists("L", $context) ? $context["L"] : (function () { throw new RuntimeError('Variable "L" does not exist.', 47, $this->source); })()) + 1);
                // line 48
                echo "            ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "taille", [], "any", false, false, false, 48) == "XL")) {
                // line 49
                echo "                ";
                $context["XL"] = ((isset($context["XL"]) || array_key_exists("XL", $context) ? $context["XL"] : (function () { throw new RuntimeError('Variable "XL" does not exist.', 49, $this->source); })()) + 1);
                // line 50
                echo "            ";
            }
            // line 51
            echo "
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "
        ";
        // line 54
        $context["Chapeau"] = 0;
        // line 55
        echo "        ";
        $context["Lunette"] = 0;
        // line 56
        echo "        ";
        $context["Maillot"] = 0;
        // line 57
        echo "        ";
        $context["Jaquette"] = 0;
        // line 58
        echo "        ";
        $context["Chaussure"] = 0;
        // line 59
        echo "
        ";
        // line 60
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 60, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 61
            echo "
        ";
            // line 62
            if ((twig_get_attribute($this->env, $this->source, $context["p"], "type", [], "any", false, false, false, 62) == "Chapeau")) {
                // line 63
                echo "        ";
                $context["Chapeau"] = ((isset($context["Chapeau"]) || array_key_exists("Chapeau", $context) ? $context["Chapeau"] : (function () { throw new RuntimeError('Variable "Chapeau" does not exist.', 63, $this->source); })()) + 1);
                // line 64
                echo "        ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "type", [], "any", false, false, false, 64) == "Lunette")) {
                // line 65
                echo "        ";
                $context["Lunette"] = ((isset($context["Lunette"]) || array_key_exists("Lunette", $context) ? $context["Lunette"] : (function () { throw new RuntimeError('Variable "Lunette" does not exist.', 65, $this->source); })()) + 1);
                // line 66
                echo "        ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "type", [], "any", false, false, false, 66) == "Maillot")) {
                // line 67
                echo "        ";
                $context["Maillot"] = ((isset($context["Maillot"]) || array_key_exists("Maillot", $context) ? $context["Maillot"] : (function () { throw new RuntimeError('Variable "Maillot" does not exist.', 67, $this->source); })()) + 1);
                // line 68
                echo "        ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "type", [], "any", false, false, false, 68) == "Jaquette")) {
                // line 69
                echo "        ";
                $context["Jaquette"] = ((isset($context["Jaquette"]) || array_key_exists("Jaquette", $context) ? $context["Jaquette"] : (function () { throw new RuntimeError('Variable "Jaquette" does not exist.', 69, $this->source); })()) + 1);
                // line 70
                echo "        ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "type", [], "any", false, false, false, 70) == "Chaussure")) {
                // line 71
                echo "        ";
                $context["Chaussure"] = ((isset($context["Chaussure"]) || array_key_exists("Chaussure", $context) ? $context["Chaussure"] : (function () { throw new RuntimeError('Variable "Chaussure" does not exist.', 71, $this->source); })()) + 1);
                // line 72
                echo "        ";
            }
            // line 73
            echo "
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        echo "
        ";
        // line 76
        $context["et1"] = 0;
        // line 77
        echo "        ";
        $context["et2"] = 0;
        // line 78
        echo "        ";
        $context["et3"] = 0;
        // line 79
        echo "        ";
        $context["et4"] = 0;
        // line 80
        echo "        ";
        $context["et5"] = 0;
        // line 81
        echo "

        ";
        // line 83
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 83, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 84
            echo "
        ";
            // line 85
            if ((twig_get_attribute($this->env, $this->source, $context["p"], "nbrEtoiles", [], "any", false, false, false, 85) == 1)) {
                // line 86
                echo "        ";
                $context["et1"] = ((isset($context["et1"]) || array_key_exists("et1", $context) ? $context["et1"] : (function () { throw new RuntimeError('Variable "et1" does not exist.', 86, $this->source); })()) + 1);
                // line 87
                echo "        ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "nbrEtoiles", [], "any", false, false, false, 87) == 2)) {
                // line 88
                echo "        ";
                $context["et2"] = ((isset($context["et2"]) || array_key_exists("et2", $context) ? $context["et2"] : (function () { throw new RuntimeError('Variable "et2" does not exist.', 88, $this->source); })()) + 1);
                // line 89
                echo "        ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "nbrEtoiles", [], "any", false, false, false, 89) == 3)) {
                // line 90
                echo "        ";
                $context["et3"] = ((isset($context["et3"]) || array_key_exists("et3", $context) ? $context["et3"] : (function () { throw new RuntimeError('Variable "et3" does not exist.', 90, $this->source); })()) + 1);
                // line 91
                echo "        ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "nbrEtoiles", [], "any", false, false, false, 91) == 4)) {
                // line 92
                echo "        ";
                $context["et4"] = ((isset($context["et4"]) || array_key_exists("et4", $context) ? $context["et4"] : (function () { throw new RuntimeError('Variable "et4" does not exist.', 92, $this->source); })()) + 1);
                // line 93
                echo "        ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["p"], "nbrEtoiles", [], "any", false, false, false, 93) == 5)) {
                // line 94
                echo "        ";
                $context["et5"] = ((isset($context["et5"]) || array_key_exists("et5", $context) ? $context["et5"] : (function () { throw new RuntimeError('Variable "et5" does not exist.', 94, $this->source); })()) + 1);
                // line 95
                echo "        ";
            }
            // line 96
            echo "
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 98
        echo "


        options={chart:{height:320,type:\"pie\"},series:[";
        // line 101
        echo twig_escape_filter($this->env, (isset($context["XS"]) || array_key_exists("XS", $context) ? $context["XS"] : (function () { throw new RuntimeError('Variable "XS" does not exist.', 101, $this->source); })()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, (isset($context["S"]) || array_key_exists("S", $context) ? $context["S"] : (function () { throw new RuntimeError('Variable "S" does not exist.', 101, $this->source); })()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, (isset($context["M"]) || array_key_exists("M", $context) ? $context["M"] : (function () { throw new RuntimeError('Variable "M" does not exist.', 101, $this->source); })()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, (isset($context["L"]) || array_key_exists("L", $context) ? $context["L"] : (function () { throw new RuntimeError('Variable "L" does not exist.', 101, $this->source); })()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, (isset($context["XL"]) || array_key_exists("XL", $context) ? $context["XL"] : (function () { throw new RuntimeError('Variable "XL" does not exist.', 101, $this->source); })()), "html", null, true);
        echo "],labels:[\"XS\",\"S\",\"M\",\"L\",\"XL\"],colors:[\"#1cbb8c\",\"#5664d2\",\"#fcb92c\",\"#4aa3ff\",\"#ff3d60\"],legend:{show:!0,position:\"bottom\",horizontalAlign:\"center\",verticalAlign:\"middle\",floating:!1,fontSize:\"14px\",offsetX:0,offsetY:5},responsive:[{breakpoint:600,options:{chart:{height:240},legend:{show:!1}}}]};(chart=new ApexCharts(document.querySelector(\"#pie_chart\"),options)).render();
        options={chart:{height:320,type:\"donut\"},series:[";
        // line 102
        echo twig_escape_filter($this->env, (isset($context["Chapeau"]) || array_key_exists("Chapeau", $context) ? $context["Chapeau"] : (function () { throw new RuntimeError('Variable "Chapeau" does not exist.', 102, $this->source); })()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, (isset($context["Lunette"]) || array_key_exists("Lunette", $context) ? $context["Lunette"] : (function () { throw new RuntimeError('Variable "Lunette" does not exist.', 102, $this->source); })()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, (isset($context["Maillot"]) || array_key_exists("Maillot", $context) ? $context["Maillot"] : (function () { throw new RuntimeError('Variable "Maillot" does not exist.', 102, $this->source); })()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, (isset($context["Jaquette"]) || array_key_exists("Jaquette", $context) ? $context["Jaquette"] : (function () { throw new RuntimeError('Variable "Jaquette" does not exist.', 102, $this->source); })()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, (isset($context["Chaussure"]) || array_key_exists("Chaussure", $context) ? $context["Chaussure"] : (function () { throw new RuntimeError('Variable "Chaussure" does not exist.', 102, $this->source); })()), "html", null, true);
        echo "],labels:[\"Chapeau\",\"Lunette\",\"Maillot\",\"Jaquette\",\"Chaussure\"],colors:[\"#1cbb8c\",\"#5664d2\",\"#fcb92c\",\"#4aa3ff\",\"#ff3d60\"],legend:{show:!0,position:\"bottom\",horizontalAlign:\"center\",verticalAlign:\"middle\",floating:!1,fontSize:\"14px\",offsetX:0,offsetY:5},responsive:[{breakpoint:600,options:{chart:{height:240},legend:{show:!1}}}]};(chart=new ApexCharts(document.querySelector(\"#donut_chart\"),options)).render();
    </script>



";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "produit/statistiques.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  330 => 102,  318 => 101,  313 => 98,  306 => 96,  303 => 95,  300 => 94,  297 => 93,  294 => 92,  291 => 91,  288 => 90,  285 => 89,  282 => 88,  279 => 87,  276 => 86,  274 => 85,  271 => 84,  267 => 83,  263 => 81,  260 => 80,  257 => 79,  254 => 78,  251 => 77,  249 => 76,  246 => 75,  239 => 73,  236 => 72,  233 => 71,  230 => 70,  227 => 69,  224 => 68,  221 => 67,  218 => 66,  215 => 65,  212 => 64,  209 => 63,  207 => 62,  204 => 61,  200 => 60,  197 => 59,  194 => 58,  191 => 57,  188 => 56,  185 => 55,  183 => 54,  180 => 53,  173 => 51,  170 => 50,  167 => 49,  164 => 48,  161 => 47,  158 => 46,  155 => 45,  152 => 44,  149 => 43,  146 => 42,  143 => 41,  141 => 40,  138 => 39,  134 => 38,  131 => 37,  128 => 36,  125 => 35,  122 => 34,  119 => 33,  117 => 32,  92 => 9,  82 => 8,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-back.html.twig' %}

{% block user %}
    {{ user }}
{% endblock %}


{% block content %}

    <div class=\"row\">
        <div class=\"col-lg-6\">
            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title mb-4\">Statistiques des Produits Par Rapport la Taille</h4>
                    <div id=\"pie_chart\" class=\"apex-charts\" dir=\"ltr\"></div>
                </div>
            </div>
        </div>
        <div class=\"col-lg-6\">
            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title mb-4\">Statistiques des Produits Par Rapport le Type</h4>

                    <div id=\"donut_chart\" class=\"apex-charts\"  dir=\"ltr\"></div>
                </div>
            </div>
        </div>
    </div>


    <script>
        {%  set XS = 0 %}
        {%  set S = 0 %}
        {%  set M = 0 %}
        {%  set L = 0 %}
        {%  set XL = 0 %}

        {% for p in produit %}

            {% if p.taille == \"XS\" %}
                {%  set XS = XS + 1 %}
             {% elseif p.taille == \"S\" %}
                {%  set S = S + 1 %}
            {% elseif p.taille == \"M\" %}
                {%  set M = M + 1 %}
            {% elseif p.taille == \"L\" %}
                {%  set L = L + 1 %}
            {% elseif p.taille == \"XL\" %}
                {%  set XL = XL + 1 %}
            {% endif %}

        {% endfor %}

        {%  set Chapeau = 0 %}
        {%  set Lunette = 0 %}
        {%  set Maillot = 0 %}
        {%  set Jaquette = 0 %}
        {%  set Chaussure = 0 %}

        {% for p in produit %}

        {% if p.type == 'Chapeau' %}
        {%  set Chapeau = Chapeau + 1 %}
        {% elseif p.type == 'Lunette' %}
        {%  set Lunette = Lunette + 1 %}
        {% elseif p.type == 'Maillot' %}
        {%  set Maillot = Maillot + 1 %}
        {% elseif p.type == 'Jaquette' %}
        {%  set Jaquette = Jaquette + 1 %}
        {% elseif p.type == 'Chaussure' %}
        {%  set Chaussure = Chaussure + 1 %}
        {% endif %}

        {% endfor %}

        {%  set et1 = 0 %}
        {%  set et2 = 0 %}
        {%  set et3 = 0 %}
        {%  set et4 = 0 %}
        {%  set et5 = 0 %}


        {% for p in produit %}

        {% if p.nbrEtoiles == 1 %}
        {%  set et1 = et1 + 1 %}
        {% elseif p.nbrEtoiles == 2 %}
        {%  set et2 = et2 + 1 %}
        {% elseif p.nbrEtoiles == 3 %}
        {%  set et3 = et3 + 1 %}
        {% elseif p.nbrEtoiles == 4 %}
        {%  set et4 = et4 + 1 %}
        {% elseif p.nbrEtoiles == 5 %}
        {%  set et5 = et5 + 1 %}
        {% endif %}

        {% endfor %}



        options={chart:{height:320,type:\"pie\"},series:[{{ XS }},{{ S }},{{ M }},{{ L }},{{ XL }}],labels:[\"XS\",\"S\",\"M\",\"L\",\"XL\"],colors:[\"#1cbb8c\",\"#5664d2\",\"#fcb92c\",\"#4aa3ff\",\"#ff3d60\"],legend:{show:!0,position:\"bottom\",horizontalAlign:\"center\",verticalAlign:\"middle\",floating:!1,fontSize:\"14px\",offsetX:0,offsetY:5},responsive:[{breakpoint:600,options:{chart:{height:240},legend:{show:!1}}}]};(chart=new ApexCharts(document.querySelector(\"#pie_chart\"),options)).render();
        options={chart:{height:320,type:\"donut\"},series:[{{ Chapeau }},{{ Lunette }},{{ Maillot }},{{ Jaquette }},{{ Chaussure }}],labels:[\"Chapeau\",\"Lunette\",\"Maillot\",\"Jaquette\",\"Chaussure\"],colors:[\"#1cbb8c\",\"#5664d2\",\"#fcb92c\",\"#4aa3ff\",\"#ff3d60\"],legend:{show:!0,position:\"bottom\",horizontalAlign:\"center\",verticalAlign:\"middle\",floating:!1,fontSize:\"14px\",offsetX:0,offsetY:5},responsive:[{breakpoint:600,options:{chart:{height:240},legend:{show:!1}}}]};(chart=new ApexCharts(document.querySelector(\"#donut_chart\"),options)).render();
    </script>



{% endblock %}
", "produit/statistiques.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\produit\\statistiques.html.twig");
    }
}
