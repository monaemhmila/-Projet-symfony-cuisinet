<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* front/fournisseurs.html.twig */
class __TwigTemplate_8bb3d28897b421cd283c8b6d95b01877957940f93af3c59c1d19752abb62b9fe extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/fournisseurs.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/fournisseurs.html.twig"));

        $this->parent = $this->loadTemplate("base-front2.html.twig", "front/fournisseurs.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "
\t\t

\t\t

\t\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t\t<div class=\"overlay\"></div>
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t\t<h1 class=\"mb-2 bread\">Fournisseur</h1>
\t\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t\t<a href=\"index.html\">Home
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t<span>Fournisseur
\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</p>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>


\t\t<section class=\"ftco-section bg-light\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"row justify-content-center mb-5 pb-2\">
\t\t\t\t\t<div class=\"col-md-7 text-center heading-section ftco-animate\">
\t\t\t\t\t\t<span class=\"subheading\">Fournisseur</span>
\t\t\t\t\t\t<h2 class=\"mb-4\">notre  Fournisseur</h2>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div
\t\t\t\t\tclass=\"row\">";
        // line 58
        echo "\t\t\t\t</div>
\t\t\t</div>
\t\t</section>

\t\t<section class=\"ftco-section ftco-wrap-about ftco-no-pb ftco-no-pt\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"row no-gutters\">
\t\t\t\t\t<div class=\"col-sm-4 p-4 p-md-5 d-flex align-items-center justify-content-center bg-primary\">
\t\t\t\t\t\t<form action=\"#\" class=\"appointment-form\">
\t\t\t\t\t\t\t<h3 class=\"mb-3\">Book your Table</h3>
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"name\" class=\"form-control\" placeholder=\"Name\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"email\" class=\"form-control\" placeholder=\"Email\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"Phone\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"input-wrap\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-calendar\"></span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control book_date\" placeholder=\"Check-In\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"input-wrap\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-clock-o\"></span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control book_time\" placeholder=\"Time\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"select-wrap\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-chevron-down\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t<select name=\"\" id=\"\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">Guest</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">1</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">2</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">3</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">4</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">5</option>
\t\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"submit\" value=\"Book Your Table Now\" class=\"btn btn-white py-3 px-4\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</form>
\t\t\t\t\t\t<!-- <a href=\"https://vimeo.com/45830194\" class=\"icon-video popup-vimeo d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t  \t\t\t\t\t\t<span class=\"ion-ios-play\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t  \t\t\t\t\t</a> -->
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-sm-8 wrap-about py-5 ftco-animate img\" style=\"background-image: url(front-office-v2/images/about.jpg);\">
\t\t\t\t\t\t<div class=\"row pb-5 pb-md-0\">
\t\t\t\t\t\t\t<div class=\"col-md-12 col-lg-7\">
\t\t\t\t\t\t\t\t<div class=\"heading-section mt-5 mb-4\">
\t\t\t\t\t\t\t\t\t<div class=\"pl-lg-3 ml-md-5\">
\t\t\t\t\t\t\t\t\t\t<span class=\"subheading\">About</span>
\t\t\t\t\t\t\t\t\t\t<h2 class=\"mb-4\">Welcome to Taste.it</h2>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"pl-lg-3 ml-md-5\">
\t\t\t\t\t\t\t\t\t<p>On her way she met a copy. The copy warned the Little Blind Text, that where it came from it would have been rewritten a thousand times and everything that was left from its origin would be the word \"and\" and the Little Blind Text should turn around and return to its own, safe country. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
\t\t\t\t\t\t\t\t\t<!-- <div class=\"thumb my-4 d-flex\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t<a href=\"#\" class=\"thumb-menu pr-md-4 text-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<div class=\"img\" style=\"background-image: url(images/lunch-4.jpg);\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<h4>Australian Organic Beef</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t<a href=\"#\" class=\"thumb-menu pr-md-4 text-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<div class=\"img\" style=\"background-image: url(images/lunch-7.jpg);\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<h4>Australian Organic Beef</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t<a href=\"#\" class=\"thumb-menu pr-md-4 text-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<div class=\"img\" style=\"background-image: url(images/lunch-6.jpg);\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<h4>Australian Organic Beef</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            </div> -->
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>
\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "front/fournisseurs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  106 => 58,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front2.html.twig' %}

{% block content %}

\t\t

\t\t

\t\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t\t<div class=\"overlay\"></div>
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t\t<h1 class=\"mb-2 bread\">Fournisseur</h1>
\t\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t\t<a href=\"index.html\">Home
\t\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t<span>Fournisseur
\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t</p>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>


\t\t<section class=\"ftco-section bg-light\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"row justify-content-center mb-5 pb-2\">
\t\t\t\t\t<div class=\"col-md-7 text-center heading-section ftco-animate\">
\t\t\t\t\t\t<span class=\"subheading\">Fournisseur</span>
\t\t\t\t\t\t<h2 class=\"mb-4\">notre  Fournisseur</h2>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div
\t\t\t\t\tclass=\"row\">{# {% for fournisseur in fournisseurs %}
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-md-6 col-lg-3 ftco-animate\">
\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"staff\">
\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"img\" style=\"background-image: url(front-office/images/chef-4.jpg);\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"text px-4 pt-2\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>{{fournisseur.nom}}</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"position mb-2\">{{fournisseur.tel}}</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"faded\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p>{{fournisseur.descfor | raw}}</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t{% endfor %} #}
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>

\t\t<section class=\"ftco-section ftco-wrap-about ftco-no-pb ftco-no-pt\">
\t\t\t<div class=\"container\">
\t\t\t\t<div class=\"row no-gutters\">
\t\t\t\t\t<div class=\"col-sm-4 p-4 p-md-5 d-flex align-items-center justify-content-center bg-primary\">
\t\t\t\t\t\t<form action=\"#\" class=\"appointment-form\">
\t\t\t\t\t\t\t<h3 class=\"mb-3\">Book your Table</h3>
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"name\" class=\"form-control\" placeholder=\"Name\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"email\" class=\"form-control\" placeholder=\"Email\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control\" placeholder=\"Phone\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"input-wrap\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-calendar\"></span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control book_date\" placeholder=\"Check-In\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"input-wrap\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-clock-o\"></span>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<input type=\"text\" class=\"form-control book_time\" placeholder=\"Time\">
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<div class=\"form-field\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"select-wrap\">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"fa fa-chevron-down\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t<select name=\"\" id=\"\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">Guest</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">1</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">2</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">3</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">4</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"\">5</option>
\t\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t<input type=\"submit\" value=\"Book Your Table Now\" class=\"btn btn-white py-3 px-4\">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</form>
\t\t\t\t\t\t<!-- <a href=\"https://vimeo.com/45830194\" class=\"icon-video popup-vimeo d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t  \t\t\t\t\t\t<span class=\"ion-ios-play\"></span>
\t\t\t\t\t\t\t\t\t\t\t\t  \t\t\t\t\t</a> -->
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"col-sm-8 wrap-about py-5 ftco-animate img\" style=\"background-image: url(front-office-v2/images/about.jpg);\">
\t\t\t\t\t\t<div class=\"row pb-5 pb-md-0\">
\t\t\t\t\t\t\t<div class=\"col-md-12 col-lg-7\">
\t\t\t\t\t\t\t\t<div class=\"heading-section mt-5 mb-4\">
\t\t\t\t\t\t\t\t\t<div class=\"pl-lg-3 ml-md-5\">
\t\t\t\t\t\t\t\t\t\t<span class=\"subheading\">About</span>
\t\t\t\t\t\t\t\t\t\t<h2 class=\"mb-4\">Welcome to Taste.it</h2>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"pl-lg-3 ml-md-5\">
\t\t\t\t\t\t\t\t\t<p>On her way she met a copy. The copy warned the Little Blind Text, that where it came from it would have been rewritten a thousand times and everything that was left from its origin would be the word \"and\" and the Little Blind Text should turn around and return to its own, safe country. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
\t\t\t\t\t\t\t\t\t<!-- <div class=\"thumb my-4 d-flex\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t<a href=\"#\" class=\"thumb-menu pr-md-4 text-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<div class=\"img\" style=\"background-image: url(images/lunch-4.jpg);\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<h4>Australian Organic Beef</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t<a href=\"#\" class=\"thumb-menu pr-md-4 text-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<div class=\"img\" style=\"background-image: url(images/lunch-7.jpg);\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<h4>Australian Organic Beef</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t<a href=\"#\" class=\"thumb-menu pr-md-4 text-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<div class=\"img\" style=\"background-image: url(images/lunch-6.jpg);\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t\t<h4>Australian Organic Beef</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            \t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t            </div> -->
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</section>
\t{% endblock %}
", "front/fournisseurs.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\front\\fournisseurs.html.twig");
    }
}
