<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* front/resetPassword/reset.html.twig */
class __TwigTemplate_599e3bef2aaddbaaa2678a64e3403578b973218ced1a3c82ec16739197c61857 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/resetPassword/reset.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/resetPassword/reset.html.twig"));

        $this->parent = $this->loadTemplate("base-front2.html.twig", "front/resetPassword/reset.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "
\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('/front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t<div class=\"overlay\"></div>
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t<h1 class=\"mb-2 bread\">User</h1>
\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t<a href=\"index.html\">User
\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span>Mot de passe oublié
\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t</span>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>
    <section class=innerpage  style=\"margin-top: 5rem; margin-bottom: 5rem;\">
\t\t<div class=\"container\">
\t\t\t<div class=\"column\">
\t\t\t\t<h2 class=\"heading\">RÉINITIALISER VOTRE
\t\t\t\t\t<span>MOT DE PASSE</span>
\t\t\t\t</h2>
\t\t\t\t<br>

\t\t\t\t<p class=\"headParagraph\"></p>

\t\t\t\t";
        // line 34
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["resetForm"]) || array_key_exists("resetForm", $context) ? $context["resetForm"] : (function () { throw new RuntimeError('Variable "resetForm" does not exist.', 34, $this->source); })()), 'form_start');
        echo "

\t\t\t\t";
        // line 36
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["resetForm"]) || array_key_exists("resetForm", $context) ? $context["resetForm"] : (function () { throw new RuntimeError('Variable "resetForm" does not exist.', 36, $this->source); })()), "plainPassword", [], "any", false, false, false, 36), 'row');
        echo "
\t\t\t\t<button class=\"btn btn-primary\">Réinitialiser le mot de passe</button>

\t\t\t\t";
        // line 39
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["resetForm"]) || array_key_exists("resetForm", $context) ? $context["resetForm"] : (function () { throw new RuntimeError('Variable "resetForm" does not exist.', 39, $this->source); })()), 'form_end');
        echo "


\t\t\t</div>


\t\t</div>
\t</div>
</section>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "front/resetPassword/reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 39,  106 => 36,  101 => 34,  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front2.html.twig' %}
{% block content %}

\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('/front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t<div class=\"overlay\"></div>
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t<h1 class=\"mb-2 bread\">User</h1>
\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t<a href=\"index.html\">User
\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span>Mot de passe oublié
\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t</span>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>
    <section class=innerpage  style=\"margin-top: 5rem; margin-bottom: 5rem;\">
\t\t<div class=\"container\">
\t\t\t<div class=\"column\">
\t\t\t\t<h2 class=\"heading\">RÉINITIALISER VOTRE
\t\t\t\t\t<span>MOT DE PASSE</span>
\t\t\t\t</h2>
\t\t\t\t<br>

\t\t\t\t<p class=\"headParagraph\"></p>

\t\t\t\t{{ form_start(resetForm) }}

\t\t\t\t{{ form_row(resetForm.plainPassword) }}
\t\t\t\t<button class=\"btn btn-primary\">Réinitialiser le mot de passe</button>

\t\t\t\t{{ form_end(resetForm) }}


\t\t\t</div>


\t\t</div>
\t</div>
</section>{% endblock %}
", "front/resetPassword/reset.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\front\\resetPassword\\reset.html.twig");
    }
}
