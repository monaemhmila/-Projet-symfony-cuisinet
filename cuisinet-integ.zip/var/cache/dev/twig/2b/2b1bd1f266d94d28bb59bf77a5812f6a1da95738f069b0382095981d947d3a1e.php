<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* favori/favoris.html.twig */
class __TwigTemplate_ed14be07884cc5ae121f2fff656c51cd7db6457fdb4a26294bc21fc58e00a60a extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'activeSouhaits' => [$this, 'block_activeSouhaits'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "favori/favoris.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "favori/favoris.html.twig"));

        $this->parent = $this->loadTemplate("base-front.html.twig", "favori/favoris.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_activeSouhaits($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeSouhaits"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeSouhaits"));

        // line 4
        echo "    class=active
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 9
        echo "
    <div class=innerbannerwrap>
        <div class=content></div>
        <div class=innerbanner><h2 class=bannerHeadline>liste <span>des souhaits</span></h2></div>
    </div>
    <section class=\"players homeplayer\">
        <div class=container>
            <div class=row><h2 class=heading>mes <span>souhaits <i class=\"fa fa-heart\"></i></span></h2>

                <p class=headParagraph></p>

                <div class=\"wrapplayer clearfix\"><a class=\"prv prev-player\"></a> <a class=\"nxt next-player\"></a>
                    <ul class=\"slideHeroes clearfix\">
                        ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["favoris"]) || array_key_exists("favoris", $context) ? $context["favoris"] : (function () { throw new RuntimeError('Variable "favoris" does not exist.', 22, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["f"]) {
            // line 23
            echo "                            <li>
                                    <div class=playerFig>
                                        <div class=playerpic>
                                            <div style=background:url(";
            // line 26
            echo twig_escape_filter($this->env, ($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/images/") . twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["f"], "produit", [], "any", false, false, false, 26), "photo", [], "any", false, false, false, 26)), "html", null, true);
            echo ") class=bgimg></div>
                                        </div>
                                        <ul class=\"playerDetails clearfix\">
                                            <li><span>";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["f"], "produit", [], "any", false, false, false, 29), "nom", [], "any", false, false, false, 29), "html", null, true);
            echo "</span></li>
                                            <li class=playinfodetails>Taille: ";
            // line 30
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["f"], "produit", [], "any", false, false, false, 30), "taille", [], "any", false, false, false, 30), "html", null, true);
            echo "</li>
                                            <li class=playerInfo><span>Prix: \$";
            // line 31
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["f"], "produit", [], "any", false, false, false, 31), "prix", [], "any", false, false, false, 31), "html", null, true);
            echo "</span> <span><i
                                                            class=\"fa fa-heart\"></i></span></li>
                                            <li class=playerInfo style=\"padding: 7px 0; text-align: center\"><a href=\"";
            // line 33
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("SupprimerFavori", ["id" => twig_get_attribute($this->env, $this->source, $context["f"], "id", [], "any", false, false, false, 33)]), "html", null, true);
            echo "\" class=\"br\">Supprimer</a></li>
                                        </ul>

                                    </div>
                            </li>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['f'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "                    </ul>
                </div>
            </div>
        </div>
    </section>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "favori/favoris.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  145 => 39,  133 => 33,  128 => 31,  124 => 30,  120 => 29,  114 => 26,  109 => 23,  105 => 22,  90 => 9,  80 => 8,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front.html.twig' %}

{% block activeSouhaits %}
    class=active
{% endblock %}


{% block content %}

    <div class=innerbannerwrap>
        <div class=content></div>
        <div class=innerbanner><h2 class=bannerHeadline>liste <span>des souhaits</span></h2></div>
    </div>
    <section class=\"players homeplayer\">
        <div class=container>
            <div class=row><h2 class=heading>mes <span>souhaits <i class=\"fa fa-heart\"></i></span></h2>

                <p class=headParagraph></p>

                <div class=\"wrapplayer clearfix\"><a class=\"prv prev-player\"></a> <a class=\"nxt next-player\"></a>
                    <ul class=\"slideHeroes clearfix\">
                        {% for f in favoris %}
                            <li>
                                    <div class=playerFig>
                                        <div class=playerpic>
                                            <div style=background:url({{ asset('uploads/images/') ~ f.produit.photo }}) class=bgimg></div>
                                        </div>
                                        <ul class=\"playerDetails clearfix\">
                                            <li><span>{{ f.produit.nom }}</span></li>
                                            <li class=playinfodetails>Taille: {{ f.produit.taille }}</li>
                                            <li class=playerInfo><span>Prix: \${{ f.produit.prix }}</span> <span><i
                                                            class=\"fa fa-heart\"></i></span></li>
                                            <li class=playerInfo style=\"padding: 7px 0; text-align: center\"><a href=\"{{ path('SupprimerFavori',{'id':f.id}) }}\" class=\"br\">Supprimer</a></li>
                                        </ul>

                                    </div>
                            </li>
                        {% endfor %}
                    </ul>
                </div>
            </div>
        </div>
    </section>

{% endblock %}



", "favori/favoris.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\favori\\favoris.html.twig");
    }
}
