<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* stade/AfficheMapStade.html.twig */
class __TwigTemplate_8960b793314847308985b5dd536a1d0eb629acd6f1e09088b1673ca34f5488f5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "stade/AfficheMapStade.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "stade/AfficheMapStade.html.twig"));

        // line 1
        $this->displayBlock('title', $context, $blocks);
        // line 21
        $this->displayBlock('content', $context, $blocks);
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 1
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        // line 2
        echo "    <meta name=\"viewport\" content=\"initial-scale=1.0, user-scalable=no\">
    <meta charset=\"utf-8\">
    <title>Location</title>
    <style>
        /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
        #map {
            height: 100%;
        }

        /* Optional: Makes the sample page fill the window. */
        html,
        body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
    </style>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 21
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 22
        echo "    <div id=\"map\"></div>
    <script>
        function initMap() {




































            var myLatLng = { lat: 25.31262442778921, lng: 51.13993868150395 };
            var AlJanoubStadium = { lat: 25.162558301351424, lng: 51.57370335187378 };
            var Jasminbinahmed = { lat: 25.26764737100803, lng: 51.48435032174067 };


            var map = new google.maps.Map(
                document.getElementById(\"map\") ,
                {
                    zoom: 6,
                    center: myLatLng,
                }
            );

            var marker= new google.maps.Marker({
                position: myLatLng,
                map: map,
                title: \"Qatar\",
            });
            var marker= new google.maps.Marker({
                position: AlJanoubStadium,
                map: map,
                title: \"Al Janoub Stadium\",
            });
            var marker= new google.maps.Marker({
                position: Jasminbinahmed,
                map: map,
                title: \"Jasmin Stadium\",
            });
        }
    </script>
    <script async w9c
                src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyDTdxaUb10x75S1mZehuzEAjEu5rzTFxCo&callback=initMap&v=weekly\">
    </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "stade/AfficheMapStade.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  105 => 22,  95 => 21,  67 => 2,  57 => 1,  47 => 21,  45 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% block title %}
    <meta name=\"viewport\" content=\"initial-scale=1.0, user-scalable=no\">
    <meta charset=\"utf-8\">
    <title>Location</title>
    <style>
        /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
        #map {
            height: 100%;
        }

        /* Optional: Makes the sample page fill the window. */
        html,
        body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
    </style>
{% endblock %}
{% block content %}
    <div id=\"map\"></div>
    <script>
        function initMap() {




































            var myLatLng = { lat: 25.31262442778921, lng: 51.13993868150395 };
            var AlJanoubStadium = { lat: 25.162558301351424, lng: 51.57370335187378 };
            var Jasminbinahmed = { lat: 25.26764737100803, lng: 51.48435032174067 };


            var map = new google.maps.Map(
                document.getElementById(\"map\") ,
                {
                    zoom: 6,
                    center: myLatLng,
                }
            );

            var marker= new google.maps.Marker({
                position: myLatLng,
                map: map,
                title: \"Qatar\",
            });
            var marker= new google.maps.Marker({
                position: AlJanoubStadium,
                map: map,
                title: \"Al Janoub Stadium\",
            });
            var marker= new google.maps.Marker({
                position: Jasminbinahmed,
                map: map,
                title: \"Jasmin Stadium\",
            });
        }
    </script>
    <script async w9c
                src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyDTdxaUb10x75S1mZehuzEAjEu5rzTFxCo&callback=initMap&v=weekly\">
    </script>
{% endblock %}", "stade/AfficheMapStade.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\stade\\AfficheMapStade.html.twig");
    }
}
