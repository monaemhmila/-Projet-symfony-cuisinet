<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* artiste/statistiques.html.twig */
class __TwigTemplate_6510bbee4c8cf0ef5d6a3330d45a5389990641bf94f1a99c9b7be594d5a68faa extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'user' => [$this, 'block_user'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-back.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "artiste/statistiques.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "artiste/statistiques.html.twig"));

        $this->parent = $this->loadTemplate("base-back.html.twig", "artiste/statistiques.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_user($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        // line 4
        echo "    ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 4, $this->source); })()), "user", [], "any", false, false, false, 4), "username", [], "any", false, false, false, 4), "html", null, true);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 8
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 9
        echo "
    <div class=\"row\">
        <div class=\"col-lg-6\">
            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title mb-4\">Statistiques des Artistes Par Rapport le Type</h4>
                    <div id=\"pie_chart\" class=\"apex-charts\" dir=\"ltr\"></div>
                </div>
            </div>
        </div>
    </div>


    <script>

        ";
        // line 24
        $context["Musicien"] = 0;
        // line 25
        echo "        ";
        $context["Chanteur"] = 0;
        // line 26
        echo "        ";
        $context["Danseur"] = 0;
        // line 27
        echo "
        ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["artistes"]) || array_key_exists("artistes", $context) ? $context["artistes"] : (function () { throw new RuntimeError('Variable "artistes" does not exist.', 28, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            // line 29
            echo "
        ";
            // line 30
            if ((twig_get_attribute($this->env, $this->source, $context["a"], "type", [], "any", false, false, false, 30) == "Musicien")) {
                // line 31
                echo "        ";
                $context["Musicien"] = ((isset($context["Musicien"]) || array_key_exists("Musicien", $context) ? $context["Musicien"] : (function () { throw new RuntimeError('Variable "Musicien" does not exist.', 31, $this->source); })()) + 1);
                // line 32
                echo "        ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["a"], "type", [], "any", false, false, false, 32) == "Chanteur")) {
                // line 33
                echo "        ";
                $context["Chanteur"] = ((isset($context["Chanteur"]) || array_key_exists("Chanteur", $context) ? $context["Chanteur"] : (function () { throw new RuntimeError('Variable "Chanteur" does not exist.', 33, $this->source); })()) + 1);
                // line 34
                echo "        ";
            } elseif ((twig_get_attribute($this->env, $this->source, $context["a"], "type", [], "any", false, false, false, 34) == "Danseur")) {
                // line 35
                echo "        ";
                $context["Danseur"] = ((isset($context["Danseur"]) || array_key_exists("Danseur", $context) ? $context["Danseur"] : (function () { throw new RuntimeError('Variable "Danseur" does not exist.', 35, $this->source); })()) + 1);
                // line 36
                echo "        ";
            }
            // line 37
            echo "
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 39
        echo "


        options={chart:{height:320,type:\"pie\"},series:[";
        // line 42
        echo twig_escape_filter($this->env, (isset($context["Musicien"]) || array_key_exists("Musicien", $context) ? $context["Musicien"] : (function () { throw new RuntimeError('Variable "Musicien" does not exist.', 42, $this->source); })()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, (isset($context["Chanteur"]) || array_key_exists("Chanteur", $context) ? $context["Chanteur"] : (function () { throw new RuntimeError('Variable "Chanteur" does not exist.', 42, $this->source); })()), "html", null, true);
        echo ",";
        echo twig_escape_filter($this->env, (isset($context["Danseur"]) || array_key_exists("Danseur", $context) ? $context["Danseur"] : (function () { throw new RuntimeError('Variable "Danseur" does not exist.', 42, $this->source); })()), "html", null, true);
        echo "],labels:[\"Musicien\",\"Chanteur\",\"Danseur\"],colors:[\"#1cbb8c\",\"#5664d2\",\"#fcb92c\"],legend:{show:!0,position:\"bottom\",horizontalAlign:\"center\",verticalAlign:\"middle\",floating:!1,fontSize:\"14px\",offsetX:0,offsetY:5},responsive:[{breakpoint:600,options:{chart:{height:240},legend:{show:!1}}}]};(chart=new ApexCharts(document.querySelector(\"#pie_chart\"),options)).render();
    </script>



";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "artiste/statistiques.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 42,  154 => 39,  147 => 37,  144 => 36,  141 => 35,  138 => 34,  135 => 33,  132 => 32,  129 => 31,  127 => 30,  124 => 29,  120 => 28,  117 => 27,  114 => 26,  111 => 25,  109 => 24,  92 => 9,  82 => 8,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-back.html.twig' %}

{% block user %}
    {{ app.user.username }}
{% endblock %}


{% block content %}

    <div class=\"row\">
        <div class=\"col-lg-6\">
            <div class=\"card\">
                <div class=\"card-body\">
                    <h4 class=\"card-title mb-4\">Statistiques des Artistes Par Rapport le Type</h4>
                    <div id=\"pie_chart\" class=\"apex-charts\" dir=\"ltr\"></div>
                </div>
            </div>
        </div>
    </div>


    <script>

        {%  set Musicien = 0 %}
        {%  set Chanteur = 0 %}
        {%  set Danseur = 0 %}

        {% for a in artistes %}

        {% if a.type == \"Musicien\" %}
        {%  set Musicien = Musicien + 1 %}
        {% elseif a.type == \"Chanteur\" %}
        {%  set Chanteur = Chanteur + 1 %}
        {% elseif a.type == \"Danseur\" %}
        {%  set Danseur = Danseur + 1 %}
        {% endif %}

        {% endfor %}



        options={chart:{height:320,type:\"pie\"},series:[{{ Musicien }},{{ Chanteur }},{{ Danseur }}],labels:[\"Musicien\",\"Chanteur\",\"Danseur\"],colors:[\"#1cbb8c\",\"#5664d2\",\"#fcb92c\"],legend:{show:!0,position:\"bottom\",horizontalAlign:\"center\",verticalAlign:\"middle\",floating:!1,fontSize:\"14px\",offsetX:0,offsetY:5},responsive:[{breakpoint:600,options:{chart:{height:240},legend:{show:!1}}}]};(chart=new ApexCharts(document.querySelector(\"#pie_chart\"),options)).render();
    </script>



{% endblock %}
", "artiste/statistiques.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\artiste\\statistiques.html.twig");
    }
}
