<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* agence/Affiche.html.twig */
class __TwigTemplate_da458d6d88a9a4c29fa244c60d6c0ce16dcf3c292c953699f45fe1d456b2eeb2 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'user' => [$this, 'block_user'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-back.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "agence/Affiche.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "agence/Affiche.html.twig"));

        $this->parent = $this->loadTemplate("base-back.html.twig", "agence/Affiche.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_user($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "user"));

        // line 3
        echo "    ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 3, $this->source); })()), "user", [], "any", false, false, false, 3), "username", [], "any", false, false, false, 3), "html", null, true);
        echo "
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 7
        echo " <!-- start page title -->
 <div class=\"row\">
    <div class=\"col-12\">
        <div class=\"page-title-box d-flex align-items-center justify-content-between\">
            <!--<h4 class=\"mb-0\">Responsive Table</h4>-->

            <div class=\"page-title-right\">
                <ol class=\"breadcrumb m-0\">
                    <li class=\"breadcrumb-item\"><a href=\"javascript: void(0);\">Agence</a></li>
                    <li class=\"breadcrumb-item active\">Afficher</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class=\"row\" style=\"width: 100%;\">
    <div class=\"col-12\">
        <div class=\"card\">
            <div class=\"card-body\">

                <h4 class=\"card-title\">Liste Des Agences</h4>
                <table id=\"datatable-buttons\" class=\"table table-striped table-bordered dt-responsive nowrap\" style=\"border-collapse: collapse; border-spacing: 0; width: 100%;\">
                    <thead class=\"thead-light\">
                        <tr>
                        <th>ID</th>
                        <th>Nom Agence</th>
                        <th>adresse Agence</th>
                        <th>numTel</th>
                        <th >Nombre d'Etoiles</th>

                        <th>Actions</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <tr ";
        // line 44
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["agence"]) || array_key_exists("agence", $context) ? $context["agence"] : (function () { throw new RuntimeError('Variable "agence" does not exist.', 44, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
            echo ">
                        
                        <td>";
            // line 46
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["a"], "id", [], "any", false, false, false, 46), "html", null, true);
            echo "</td>
                        <td>";
            // line 47
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["a"], "nom", [], "any", false, false, false, 47), "html", null, true);
            echo "</td>
                        <td>";
            // line 48
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["a"], "adresse", [], "any", false, false, false, 48), "html", null, true);
            echo "</td>
                        <td>";
            // line 49
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["a"], "numTel", [], "any", false, false, false, 49), "html", null, true);
            echo "</td>
                        <td>";
            // line 50
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(0, twig_get_attribute($this->env, $this->source, $context["a"], "NbEtoiles", [], "any", false, false, false, 50)));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 51
                echo "                            <i class=\"fa fa-star\"></i>
                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 52
            echo "</td>

                        
                        <td><a href=\"";
            // line 55
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("Update", ["id" => twig_get_attribute($this->env, $this->source, $context["a"], "id", [], "any", false, false, false, 55)]), "html", null, true);
            echo "\"><i class=\"ri-pencil-fill\"></i></a>     <a href=\"";
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("deleteAgence", ["id" => twig_get_attribute($this->env, $this->source, $context["a"], "id", [], "any", false, false, false, 55)]), "html", null, true);
            echo "\"><i class=\"ri-delete-bin-fill\"></i></a></td>

                    </tr";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo ">

                </tbody>

            </table>
        </div>
    </div>
</div> <!-- end col -->
</div> <!-- end row -->
 <script>
        \$('#datatable-buttons').DataTable()
    </script>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "agence/Affiche.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  181 => 57,  170 => 55,  165 => 52,  158 => 51,  154 => 50,  150 => 49,  146 => 48,  142 => 47,  138 => 46,  131 => 44,  92 => 7,  82 => 6,  69 => 3,  59 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-back.html.twig' %}
{% block user %}
    {{ app.user.username }}
{% endblock %}

{% block content %}
 <!-- start page title -->
 <div class=\"row\">
    <div class=\"col-12\">
        <div class=\"page-title-box d-flex align-items-center justify-content-between\">
            <!--<h4 class=\"mb-0\">Responsive Table</h4>-->

            <div class=\"page-title-right\">
                <ol class=\"breadcrumb m-0\">
                    <li class=\"breadcrumb-item\"><a href=\"javascript: void(0);\">Agence</a></li>
                    <li class=\"breadcrumb-item active\">Afficher</li>
                </ol>
            </div>

        </div>
    </div>
</div>

<div class=\"row\" style=\"width: 100%;\">
    <div class=\"col-12\">
        <div class=\"card\">
            <div class=\"card-body\">

                <h4 class=\"card-title\">Liste Des Agences</h4>
                <table id=\"datatable-buttons\" class=\"table table-striped table-bordered dt-responsive nowrap\" style=\"border-collapse: collapse; border-spacing: 0; width: 100%;\">
                    <thead class=\"thead-light\">
                        <tr>
                        <th>ID</th>
                        <th>Nom Agence</th>
                        <th>adresse Agence</th>
                        <th>numTel</th>
                        <th >Nombre d'Etoiles</th>

                        <th>Actions</th>
                       
                    </tr>
                </thead>
                <tbody>
                    <tr {% for a in agence %}>
                        
                        <td>{{ a.id }}</td>
                        <td>{{ a.nom }}</td>
                        <td>{{ a.adresse }}</td>
                        <td>{{ a.numTel }}</td>
                        <td>{% for i in 0..a.NbEtoiles %}
                            <i class=\"fa fa-star\"></i>
                        {% endfor %}</td>

                        
                        <td><a href=\"{{ path('Update',{'id':a.id}) }}\"><i class=\"ri-pencil-fill\"></i></a>     <a href=\"{{ path('deleteAgence',{'id':a.id}) }}\"><i class=\"ri-delete-bin-fill\"></i></a></td>

                    </tr{% endfor %}>

                </tbody>

            </table>
        </div>
    </div>
</div> <!-- end col -->
</div> <!-- end row -->
 <script>
        \$('#datatable-buttons').DataTable()
    </script>

{% endblock %}
", "agence/Affiche.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\agence\\Affiche.html.twig");
    }
}
