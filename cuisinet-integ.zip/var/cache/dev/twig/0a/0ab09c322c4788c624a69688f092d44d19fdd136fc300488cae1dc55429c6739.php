<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/index.html.twig */
class __TwigTemplate_beb3e405dbf5c0da112ba898bee717245991a3f92622fc32276b486bed392882 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'activeAccueil' => [$this, 'block_activeAccueil'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $this->parent = $this->loadTemplate("base-front.html.twig", "home/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_activeAccueil($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeAccueil"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeAccueil"));

        // line 4
        echo "\tclass=active
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 8
        echo "
\t<div class=\"cuisinet-banner\">
\t\t<div class=\"cuisinet-banner-text\">
\t\t\t<h1>Bienvenu à Cuisinet</h1>
\t\t\t<p>
\t\t\t\tChez Cuisinet, il n’y a d’autre ambition que celle de proposer une cuisine <br>
\t\t\t\tsincère, ancrée dans les saisons, authentique mais moderne, joyeuse<br>
\t\t\t\tet généreuse, aux inspirations larges.
                Ici, vous trouverez des plats de cuisine authentiques et de qualité. <br>
                Pour vous et vos amis.

\t\t\t</p>
\t\t</div>

\t</div>
\t<div class=\"banner-text\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">l'action commence à partir du 8<sup></sup>
\t\t\t\tmars , 2022.</div>
\t\t</div>
\t</div>

\t<!---------------------------------------------Block------------------------------------------------------>

\t<section class=\"product bg-white\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<h2 class=\"heading\">
\t\t\t\t\t<span>PRODUITS</span>
\t\t\t\t\tRECOMMANDÉS
\t\t\t\t</h2>
\t\t\t\t<p class=\"headParagraph\"></p>
\t\t\t\t<ul
\t\t\t\t\tclass=\"product_details\">";
        // line 54
        echo "\t\t\t\t</ul>
\t\t\t\t<div class=\"center\">
\t\t\t\t\t<a href=\"#\" class=\"btn btn-red\">Visitez Notre Boutique</a>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>

\t<!---------------------------------------------END Block ------------------------------------------------------>


</section>

<script type=\"text/javascript\">
\t\$(function () {
\$('#da_gallery .gallery-list ').hoverdir();
});
</script>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 54,  90 => 8,  80 => 7,  69 => 4,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front.html.twig' %}

{% block activeAccueil %}
\tclass=active
{% endblock %}

{% block content %}

\t<div class=\"cuisinet-banner\">
\t\t<div class=\"cuisinet-banner-text\">
\t\t\t<h1>Bienvenu à Cuisinet</h1>
\t\t\t<p>
\t\t\t\tChez Cuisinet, il n’y a d’autre ambition que celle de proposer une cuisine <br>
\t\t\t\tsincère, ancrée dans les saisons, authentique mais moderne, joyeuse<br>
\t\t\t\tet généreuse, aux inspirations larges.
                Ici, vous trouverez des plats de cuisine authentiques et de qualité. <br>
                Pour vous et vos amis.

\t\t\t</p>
\t\t</div>

\t</div>
\t<div class=\"banner-text\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">l'action commence à partir du 8<sup></sup>
\t\t\t\tmars , 2022.</div>
\t\t</div>
\t</div>

\t<!---------------------------------------------Block------------------------------------------------------>

\t<section class=\"product bg-white\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<h2 class=\"heading\">
\t\t\t\t\t<span>PRODUITS</span>
\t\t\t\t\tRECOMMANDÉS
\t\t\t\t</h2>
\t\t\t\t<p class=\"headParagraph\"></p>
\t\t\t\t<ul
\t\t\t\t\tclass=\"product_details\">{# {% for p in produits %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                        <li><a href=\"#\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                            <div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                                <div class=product-img
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                                     style=\"background:url({{ asset('uploads/images/') ~ p.photo }}) center no-repeat\"></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                            </div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                            <ul class=\"oswald16 product_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                                <li class=detailsContainer><span>{{ p.nom }}</span> <span>Taille: {{ p.taille }}</span></li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                                <li class=cartContainer><span>Prix: </span> <span class=price>\${{ p.prix }}</span></li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                            </ul>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                            </a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                        </li>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                    {% endfor %} #}
\t\t\t\t</ul>
\t\t\t\t<div class=\"center\">
\t\t\t\t\t<a href=\"#\" class=\"btn btn-red\">Visitez Notre Boutique</a>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>

\t<!---------------------------------------------END Block ------------------------------------------------------>


</section>

<script type=\"text/javascript\">
\t\$(function () {
\$('#da_gallery .gallery-list ').hoverdir();
});
</script>{% endblock %}
", "home/index.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\home\\index.html.twig");
    }
}
