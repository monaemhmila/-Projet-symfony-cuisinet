<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* front/login.html.twig */
class __TwigTemplate_aeb0c5be7d699abbedb9a11766cf0972762734ca8c5e564736e7b6444ee9ebac extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/login.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/login.html.twig"));

        $this->parent = $this->loadTemplate("base-front2.html.twig", "front/login.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "
\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t<div class=\"overlay\"></div>
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t<h1 class=\"mb-2 bread\">User</h1>
\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t<a href=\"index.html\">User
\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span>Login
\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t</span>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>
\t<section class=\"innerpage_all_wrap\" style=\"margin-top: 5rem; margin-bottom: 5rem;\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<h2 class=\"heading\">SE CONNECTER 
\t\t\t\t\t<span>A VOTRE COMPTE</span>
\t\t\t\t</h2>


\t\t\t\t<form action=\"\" class=\"appointment-form\" method=\"POST\">


\t\t\t\t\t";
        // line 36
        if ((isset($context["error"]) || array_key_exists("error", $context) ? $context["error"] : (function () { throw new RuntimeError('Variable "error" does not exist.', 36, $this->source); })())) {
            // line 37
            echo "\t\t\t\t\t\t<div class=\"alert alert-danger\">les informations d'identification invalides !</div>
\t\t\t\t\t";
        }
        // line 39
        echo "
\t\t\t\t\t";
        // line 40
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 40, $this->source); })()), "user", [], "any", false, false, false, 40)) {
            // line 41
            echo "\t\t\t\t\t\t<div class=\"mb-3\">
\t\t\t\t\t\t\tVous êtes connecté en tant que
\t\t\t\t\t\t\t";
            // line 43
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 43, $this->source); })()), "user", [], "any", false, false, false, 43), "username", [], "any", false, false, false, 43), "html", null, true);
            echo ",
\t\t\t\t\t\t\t<a href=\"";
            // line 44
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_logout");
            echo "\">Se déconnecter</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 47
        echo "\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<div class=\"form-group\" style=\"background-color: #262626;\">
\t\t\t\t\t\t\t\t<input type=\"text\" value=\"";
        // line 50
        echo twig_escape_filter($this->env, (isset($context["last_username"]) || array_key_exists("last_username", $context) ? $context["last_username"] : (function () { throw new RuntimeError('Variable "last_username" does not exist.', 50, $this->source); })()), "html", null, true);
        echo "\" name=\"username\" id=\"inputUsername\" class=\"form-control\" autocomplete=\"username\" required autofocus placeholder=\"Nom d'utilisateur\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<div class=\"form-group\" style=\"background-color: #262626;\">
\t\t\t\t\t\t\t\t<input type=\"password\" name=\"password\" id=\"inputPassword\" class=\"form-control\" autocomplete=\"current-password\" required placeholder=\"Mot de Passe\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div style=\"margin-top: 10px; margin-left: 14px;\" >
\t\t\t\t\t\t\t<a href=\"";
        // line 59
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("app_forgot_password_request");
        echo "\" class=\"text-muted\">
\t\t\t\t\t\t\t\t<i class=\"mdi mdi-lock\"></i>
\t\t\t\t\t\t\t\tMot de passe oublié?</a>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<input type=\"submit\" value=\"Login\" class=\"btn btn-primary py-3 px-4\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 69
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\">
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t</div>


\t\t</div>
\t</div>
</section>";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "front/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  157 => 69,  144 => 59,  132 => 50,  127 => 47,  121 => 44,  117 => 43,  113 => 41,  111 => 40,  108 => 39,  104 => 37,  102 => 36,  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front2.html.twig' %}

{% block content %}

\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t<div class=\"overlay\"></div>
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t<h1 class=\"mb-2 bread\">User</h1>
\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t<a href=\"index.html\">User
\t\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t\t<span>Login
\t\t\t\t\t\t\t<i class=\"fa fa-chevron-right\"></i>
\t\t\t\t\t\t</span>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>
\t<section class=\"innerpage_all_wrap\" style=\"margin-top: 5rem; margin-bottom: 5rem;\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<h2 class=\"heading\">SE CONNECTER 
\t\t\t\t\t<span>A VOTRE COMPTE</span>
\t\t\t\t</h2>


\t\t\t\t<form action=\"\" class=\"appointment-form\" method=\"POST\">


\t\t\t\t\t{% if error %}
\t\t\t\t\t\t<div class=\"alert alert-danger\">les informations d'identification invalides !</div>
\t\t\t\t\t{% endif %}

\t\t\t\t\t{% if app.user %}
\t\t\t\t\t\t<div class=\"mb-3\">
\t\t\t\t\t\t\tVous êtes connecté en tant que
\t\t\t\t\t\t\t{{ app.user.username }},
\t\t\t\t\t\t\t<a href=\"{{ path('app_logout') }}\">Se déconnecter</a>
\t\t\t\t\t\t</div>
\t\t\t\t\t{% endif %}
\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<div class=\"form-group\" style=\"background-color: #262626;\">
\t\t\t\t\t\t\t\t<input type=\"text\" value=\"{{ last_username }}\" name=\"username\" id=\"inputUsername\" class=\"form-control\" autocomplete=\"username\" required autofocus placeholder=\"Nom d'utilisateur\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<div class=\"form-group\" style=\"background-color: #262626;\">
\t\t\t\t\t\t\t\t<input type=\"password\" name=\"password\" id=\"inputPassword\" class=\"form-control\" autocomplete=\"current-password\" required placeholder=\"Mot de Passe\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div style=\"margin-top: 10px; margin-left: 14px;\" >
\t\t\t\t\t\t\t<a href=\"{{ path('app_forgot_password_request') }}\" class=\"text-muted\">
\t\t\t\t\t\t\t\t<i class=\"mdi mdi-lock\"></i>
\t\t\t\t\t\t\t\tMot de passe oublié?</a>
\t\t\t\t\t\t</div>

\t\t\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t<input type=\"submit\" value=\"Login\" class=\"btn btn-primary py-3 px-4\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\">
\t\t\t\t\t</div>
\t\t\t\t</form>
\t\t\t</div>


\t\t</div>
\t</div>
</section>{% endblock %}
", "front/login.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\front\\login.html.twig");
    }
}
