<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* reservation/AfficheBI.html.twig */
class __TwigTemplate_9eb60327049a31153b152435678f8bd44cfc7a695100561d65e760f6a6eb4e74 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "reservation/AfficheBI.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "reservation/AfficheBI.html.twig"));

        $this->parent = $this->loadTemplate("base-front.html.twig", "reservation/AfficheBI.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "<div class=innerbannerwrap>
    <div class=content></div>
    <div   class=innerbanner><h2 class=bannerHeadline><span>    Mes Réservations  </span> </h2></div>
</div>
    <section class=\"matchSchedule countryclub\">
    <div class=container>
        <div class=row>
            <li class=clearfix>
                <div>
                    <div>
                        <div class=fig01>
                            
                        
            
                        <div class=\"bg-black01 fig02\">
                            <h6 class=\"uppercaseheading red\"><p class=paragraph02>Voucher  ";
        // line 18
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 18, $this->source); })()), "id", [], "any", false, false, false, 18), "html", null, true);
        echo "</p></h6>
            
                           <div > <p >Notre Client ";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 20, $this->source); })()), "user", [], "any", false, false, false, 20), "nom", [], "any", false, false, false, 20), "html", null, true);
        echo " à reservé dans l'hotel ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 20, $this->source); })()), "hebergement", [], "any", false, false, false, 20), "NomH", [], "any", false, false, false, 20), "html", null, true);
        echo " depuis notre agence ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 20, $this->source); })()), "hebergement", [], "any", false, false, false, 20), "agence", [], "any", false, false, false, 20), "Nom", [], "any", false, false, false, 20), "html", null, true);
        echo " </p></div>   
            
                           <p>The FIFA World Cup Qatar 2022™ is less than a year away. Your host country, Qatar, offers an exciting range of accommodation – available to book soon..</p>

                           <p >Experience a FIFA World Cup™like no other.</p>                       
                            <div ><p>la durée de reservation est de  : ";
        // line 25
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 25, $this->source); })()), "dateDebut", [], "any", false, false, false, 25), "d-m-Y"), "html", null, true);
        echo " jusqua : ";
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 25, $this->source); })()), "dateFin", [], "any", false, false, false, 25), "d-m-Y"), "html", null, true);
        echo "</p></div>
                                
                        </div>
                        <div class=\"bg-redcolor fig02\"><p><a class=\"uppercaseheading green\">Imprimer</a></p></div>
            
                    </div>
                </div>
            
            </li>
            </div>
        </div>
        
                        
        
        
        </section>
        <script type=text/javascript>
            \$(function () {
                \$('#da_gallery .gallery-list ').hoverdir();
            });
        </script>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "reservation/AfficheBI.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 25,  90 => 20,  85 => 18,  68 => 3,  58 => 2,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front.html.twig' %}
{% block content %}
<div class=innerbannerwrap>
    <div class=content></div>
    <div   class=innerbanner><h2 class=bannerHeadline><span>    Mes Réservations  </span> </h2></div>
</div>
    <section class=\"matchSchedule countryclub\">
    <div class=container>
        <div class=row>
            <li class=clearfix>
                <div>
                    <div>
                        <div class=fig01>
                            
                        
            
                        <div class=\"bg-black01 fig02\">
                            <h6 class=\"uppercaseheading red\"><p class=paragraph02>Voucher  {{ reservation.id }}</p></h6>
            
                           <div > <p >Notre Client {{ reservation.user.nom }} à reservé dans l'hotel {{ reservation.hebergement.NomH }} depuis notre agence {{ reservation.hebergement.agence.Nom }} </p></div>   
            
                           <p>The FIFA World Cup Qatar 2022™ is less than a year away. Your host country, Qatar, offers an exciting range of accommodation – available to book soon..</p>

                           <p >Experience a FIFA World Cup™like no other.</p>                       
                            <div ><p>la durée de reservation est de  : {{ reservation.dateDebut|date('d-m-Y') }} jusqua : {{ reservation.dateFin|date('d-m-Y') }}</p></div>
                                
                        </div>
                        <div class=\"bg-redcolor fig02\"><p><a class=\"uppercaseheading green\">Imprimer</a></p></div>
            
                    </div>
                </div>
            
            </li>
            </div>
        </div>
        
                        
        
        
        </section>
        <script type=text/javascript>
            \$(function () {
                \$('#da_gallery .gallery-list ').hoverdir();
            });
        </script>
{% endblock %}

", "reservation/AfficheBI.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\reservation\\AfficheBI.html.twig");
    }
}
