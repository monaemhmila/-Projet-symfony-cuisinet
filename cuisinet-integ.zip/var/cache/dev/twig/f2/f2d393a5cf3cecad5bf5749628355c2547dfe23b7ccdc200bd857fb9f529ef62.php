<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* reservation/Voucher.html.twig */
class __TwigTemplate_ad14727dd8edd6ebeacd16ff9edabe79a28571f2da36613ade5115a94c708e00 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "reservation/Voucher.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "reservation/Voucher.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>

    <!-- Stylesheets -->
    <link href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/css/responsive.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/css/style.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/css/datepicker.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/css/jquery.range.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/vendor/bootstrap/css/bootstrap.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/vendor/fontawesome-free/css/all.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/vendor/OwlCarousel/assets/owl.carousel.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">
    <link href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/vendor/OwlCarousel/assets/owl.theme.default.min.css"), "html", null, true);
        echo "\" rel=\"stylesheet\">

    <!-- Semantic Css -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/vendor/semantic/semantic.min.css"), "html", null, true);
        echo "\">

</head>
<body class=\"main_invoice\">
<!-- Header Start -->
<div class=\"invc_header\">
    <div class=\"container\">
        <div class=\"row justify-content-md-center\">
            <div class=\"col-md-8 col-sm-12\">
                <div class=\"\">
                    <div class=\"header_logo\">
                        <img src=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/images/logo.PNG"), "html", null, true);
        echo "\" alt=\"\">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Header End -->
<!-- Invoice Body Start -->
<section class=\"invoice_section\">
    <div class=\"container\">
        <div class=\"row justify-content-md-center\">
            <div class=\"col-md-8\">
                <div class=\"invoice_body\">
                    <div class=\"nvdate_dt\">
                        <div class=\"nvde_dt45\">

                        </div>
                        <div class=\"nvde_dt46\">
                            <ul class=\"in11448\">
                               
                                <li><div class=\"vdt-list\"><span>Agence :</span> ";
        // line 48
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 48, $this->source); })()), "hebergement", [], "any", false, false, false, 48), "agence", [], "any", false, false, false, 48), "Nom", [], "any", false, false, false, 48), "html", null, true);
        echo "</div></li>
                                <li><div class=\"vdt-list\"><span>Numéro :</span> ";
        // line 49
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 49, $this->source); })()), "hebergement", [], "any", false, false, false, 49), "agence", [], "any", false, false, false, 49), "NumTel", [], "any", false, false, false, 49), "html", null, true);
        echo "</div></li>

                            </ul>
                        </div>
                    </div>
                    <h3 class=\"dff474\">Voucher</h3>
                    <div class=\"jike145\">
                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"vhls140\">
                                    <h4>Client</h4>
                                    <ul>
                                        <li><div class=\"vdt-list\"> Nom : ";
        // line 61
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 61, $this->source); })()), "user", [], "any", false, false, false, 61), "nom", [], "any", false, false, false, 61), "html", null, true);
        echo "</div></li>
                                        <li><div class=\"vdt-list\"> Prénom : ";
        // line 62
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 62, $this->source); })()), "user", [], "any", false, false, false, 62), "prenom", [], "any", false, false, false, 62), "html", null, true);
        echo "</div></li>
                                        <li><div class=\"vdt-list\"> ID : ";
        // line 63
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 63, $this->source); })()), "user", [], "any", false, false, false, 63), "id", [], "any", false, false, false, 63), "html", null, true);
        echo " </div></li>
                                        <li><div class=\"vdt-list\"> Email : ";
        // line 64
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 64, $this->source); })()), "user", [], "any", false, false, false, 64), "email", [], "any", false, false, false, 64), "html", null, true);
        echo "</div></li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                   
                            <table class=\"table table-borderless\">
                                <thead>
                                <tr>
                                    <th scope=\"col\">ID de Redeseravtion</th>
                                    <th scope=\"col\">Check-in</th>
                                    <th scope=\"col\">check-out</th>
                                    <th scope=\"col\"></th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope=\"row\">
                                        <div class=\"user_dt_trans\">
                                            <p>";
        // line 85
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 85, $this->source); })()), "id", [], "any", false, false, false, 85), "html", null, true);
        echo "</p>
                                        </div>
                                    </th>
                                    <td>
                                        <div class=\"user_dt_trans\">
                                            <p>";
        // line 90
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 90, $this->source); })()), "dateDebut", [], "any", false, false, false, 90), "d-m-Y"), "html", null, true);
        echo "</p>
                                        </div>
                                    </td>
                                    <td>
                                        <div class=\"user_dt_trans\">
                                            <p>";
        // line 95
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 95, $this->source); })()), "dateFin", [], "any", false, false, false, 95), "d-m-Y"), "html", null, true);
        echo "</p>
                                        </div>
                                    </td>
                                  
                                </tr>
                                <tr>
                                    <th scope=\"row\"></th>
                                    <td colspan=\"3\">
                                        <div class=\"user_dt_trans jsk1145\">
                                            <div class=\"totalinv2\">";
        // line 104
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 104, $this->source); })()), "hebergement", [], "any", false, false, false, 104), "NomH", [], "any", false, false, false, 104), "html", null, true);
        echo "</div>
                                            <p>";
        // line 105
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["reservation"]) || array_key_exists("reservation", $context) ? $context["reservation"] : (function () { throw new RuntimeError('Variable "reservation" does not exist.', 105, $this->source); })()), "hebergement", [], "any", false, false, false, 105), "adresse", [], "any", false, false, false, 105), "html", null, true);
        echo "</p>
                                        </div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        
                    <div class=\"invoice_footer\">
                        <div class=\"leftfooter\">
                           
                        </div>
                        <div class=\"righttfooter\">
                            <a class=\"print_btn\" href=\"javascript:window.print();\">Print</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Invoice Body End -->

<!-- Scroll to Top Button Start -->
<button onclick=\"topFunction()\" id=\"pageup\" title=\"Go to top\"><i class=\"fas fa-arrow-up\"></i></button>
<!-- Scroll to Top Button End -->

<!-- Scripts js -->
<script src=\"";
        // line 132
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/js/jquery.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 133
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/js/datepicker.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 134
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/js/i18n/datepicker.en.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 135
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/vendor/bootstrap/js/bootstrap.bundle.min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 136
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/vendor/OwlCarousel/owl.carousel.js"), "html", null, true);
        echo "\"></script>
<script src=";
        // line 137
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/\"vendor/semantic/semantic.min.js\""), "html", null, true);
        echo "></script>
<script src=\"";
        // line 138
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/js/jquery.range-min.js"), "html", null, true);
        echo "\"></script>
<script src=\"";
        // line 139
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("Facture/js/custom1.js"), "html", null, true);
        echo "\"></script>


</body>

</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "reservation/Voucher.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  267 => 139,  263 => 138,  259 => 137,  255 => 136,  251 => 135,  247 => 134,  243 => 133,  239 => 132,  209 => 105,  205 => 104,  193 => 95,  185 => 90,  177 => 85,  153 => 64,  149 => 63,  145 => 62,  141 => 61,  126 => 49,  122 => 48,  98 => 27,  84 => 16,  78 => 13,  74 => 12,  70 => 11,  66 => 10,  62 => 9,  58 => 8,  54 => 7,  50 => 6,  43 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!DOCTYPE html>
<html lang=\"en\">
<head>

    <!-- Stylesheets -->
    <link href=\"{{ asset('Facture/css/responsive.css')}}\" rel=\"stylesheet\">
    <link href=\"{{ asset('Facture/css/style.css')}}\" rel=\"stylesheet\">
    <link href=\"{{ asset('Facture/css/datepicker.min.css')}}\" rel=\"stylesheet\">
    <link href=\"{{ asset('Facture/css/jquery.range.css')}}\" rel=\"stylesheet\">
    <link href=\"{{ asset('Facture/vendor/bootstrap/css/bootstrap.min.css')}}\" rel=\"stylesheet\">
    <link href=\"{{ asset('Facture/vendor/fontawesome-free/css/all.min.css')}}\" rel=\"stylesheet\">
    <link href=\"{{ asset('Facture/vendor/OwlCarousel/assets/owl.carousel.css')}}\" rel=\"stylesheet\">
    <link href=\"{{ asset('Facture/vendor/OwlCarousel/assets/owl.theme.default.min.css')}}\" rel=\"stylesheet\">

    <!-- Semantic Css -->
    <link rel=\"stylesheet\" type=\"text/css\" href=\"{{ asset('Facture/vendor/semantic/semantic.min.css')}}\">

</head>
<body class=\"main_invoice\">
<!-- Header Start -->
<div class=\"invc_header\">
    <div class=\"container\">
        <div class=\"row justify-content-md-center\">
            <div class=\"col-md-8 col-sm-12\">
                <div class=\"\">
                    <div class=\"header_logo\">
                        <img src=\"{{ asset('Facture/images/logo.PNG')}}\" alt=\"\">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Header End -->
<!-- Invoice Body Start -->
<section class=\"invoice_section\">
    <div class=\"container\">
        <div class=\"row justify-content-md-center\">
            <div class=\"col-md-8\">
                <div class=\"invoice_body\">
                    <div class=\"nvdate_dt\">
                        <div class=\"nvde_dt45\">

                        </div>
                        <div class=\"nvde_dt46\">
                            <ul class=\"in11448\">
                               
                                <li><div class=\"vdt-list\"><span>Agence :</span> {{ reservation.hebergement.agence.Nom }}</div></li>
                                <li><div class=\"vdt-list\"><span>Numéro :</span> {{ reservation.hebergement.agence.NumTel }}</div></li>

                            </ul>
                        </div>
                    </div>
                    <h3 class=\"dff474\">Voucher</h3>
                    <div class=\"jike145\">
                        <div class=\"row\">
                            <div class=\"col-md-6\">
                                <div class=\"vhls140\">
                                    <h4>Client</h4>
                                    <ul>
                                        <li><div class=\"vdt-list\"> Nom : {{ reservation.user.nom }}</div></li>
                                        <li><div class=\"vdt-list\"> Prénom : {{ reservation.user.prenom }}</div></li>
                                        <li><div class=\"vdt-list\"> ID : {{ reservation.user.id }} </div></li>
                                        <li><div class=\"vdt-list\"> Email : {{ reservation.user.email }}</div></li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                   
                            <table class=\"table table-borderless\">
                                <thead>
                                <tr>
                                    <th scope=\"col\">ID de Redeseravtion</th>
                                    <th scope=\"col\">Check-in</th>
                                    <th scope=\"col\">check-out</th>
                                    <th scope=\"col\"></th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <th scope=\"row\">
                                        <div class=\"user_dt_trans\">
                                            <p>{{ reservation.id }}</p>
                                        </div>
                                    </th>
                                    <td>
                                        <div class=\"user_dt_trans\">
                                            <p>{{ reservation.dateDebut|date('d-m-Y') }}</p>
                                        </div>
                                    </td>
                                    <td>
                                        <div class=\"user_dt_trans\">
                                            <p>{{ reservation.dateFin|date('d-m-Y') }}</p>
                                        </div>
                                    </td>
                                  
                                </tr>
                                <tr>
                                    <th scope=\"row\"></th>
                                    <td colspan=\"3\">
                                        <div class=\"user_dt_trans jsk1145\">
                                            <div class=\"totalinv2\">{{ reservation.hebergement.NomH }}</div>
                                            <p>{{ reservation.hebergement.adresse }}</p>
                                        </div>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        
                    <div class=\"invoice_footer\">
                        <div class=\"leftfooter\">
                           
                        </div>
                        <div class=\"righttfooter\">
                            <a class=\"print_btn\" href=\"javascript:window.print();\">Print</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Invoice Body End -->

<!-- Scroll to Top Button Start -->
<button onclick=\"topFunction()\" id=\"pageup\" title=\"Go to top\"><i class=\"fas fa-arrow-up\"></i></button>
<!-- Scroll to Top Button End -->

<!-- Scripts js -->
<script src=\"{{ asset('Facture/js/jquery.min.js')}}\"></script>
<script src=\"{{ asset('Facture/js/datepicker.min.js')}}\"></script>
<script src=\"{{ asset('Facture/js/i18n/datepicker.en.js')}}\"></script>
<script src=\"{{ asset('Facture/vendor/bootstrap/js/bootstrap.bundle.min.js')}}\"></script>
<script src=\"{{ asset('Facture/vendor/OwlCarousel/owl.carousel.js')}}\"></script>
<script src={{ asset('Facture/\"vendor/semantic/semantic.min.js\"')}}></script>
<script src=\"{{ asset('Facture/js/jquery.range-min.js')}}\"></script>
<script src=\"{{ asset('Facture/js/custom1.js')}}\"></script>


</body>

</html>", "reservation/Voucher.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\reservation\\Voucher.html.twig");
    }
}
