<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* produit/afficherFront.html.twig */
class __TwigTemplate_1aac2594dbef682a8ccf85cab9fc9d8729260c29fa25b0bf5a04c5cc0e458ef6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'activeBoutique' => [$this, 'block_activeBoutique'],
            'panier' => [$this, 'block_panier'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "produit/afficherFront.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "produit/afficherFront.html.twig"));

        $this->parent = $this->loadTemplate("base-front.html.twig", "produit/afficherFront.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_activeBoutique($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeBoutique"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeBoutique"));

        // line 4
        echo "class=active
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_panier($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "panier"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "panier"));

        // line 8
        echo "
    <li><a href=\"";
        // line 9
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("EnrichirPanier");
        echo "\"><i class=\"fa fa-shopping-cart\"></i> <span>cart(<span>
                        ";
        // line 10
        if ((twig_length_filter($this->env, (isset($context["panier"]) || array_key_exists("panier", $context) ? $context["panier"] : (function () { throw new RuntimeError('Variable "panier" does not exist.', 10, $this->source); })())) > 0)) {
            // line 11
            echo "                            ";
            echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["panier"]) || array_key_exists("panier", $context) ? $context["panier"] : (function () { throw new RuntimeError('Variable "panier" does not exist.', 11, $this->source); })())), "html", null, true);
            echo "
                        ";
        } else {
            // line 13
            echo "                            0
                        ";
        }
        // line 15
        echo "                </span>)</span></a></li>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 21
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 22
        echo "
    <div class=innerbannerwrap>
        <div class=content></div>
        <div class=innerbanner><h2 class=bannerHeadline>Notre <span>Boutique</span></h2></div>
    </div>
    <section class=innerpage_all_wrap>
        <div class=container>
            <div class=row><h2 class=heading>Meilleur Boutique <span>d'Accessoires de Football</span></h2>

                <p class=headParagraph></p>

                <div class=innerWrapper>
                    <aside class=\"widgetinner clearfix\">
                        <div class=widgetinfowrap>
                            <div class=bg-blackimg>Chercher par Couleur</div>
                            <div class=sizepic>

                                <a title=\"Noir\" href=\"";
        // line 39
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Noir"]);
        echo "\" style=\"background-color: black\"></a>
                                <a title=\"Gris\" href=\"";
        // line 40
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Gris"]);
        echo "\" style=\"background-color: grey\"></a>
                                <a title=\"Marron\" href=\"";
        // line 41
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Marron"]);
        echo "\" style=\"background-color: saddlebrown\"></a>
                                <a title=\"Vert\" href=\"";
        // line 42
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Vert"]);
        echo "\" style=\"background-color: green\"></a>
                                <a title=\"Bleu\" href=\"";
        // line 43
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Bleu"]);
        echo "\" style=\"background-color: blue\"></a>
                                <a title=\"Rouge\" href=\"";
        // line 44
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Rouge"]);
        echo "\" style=\"background-color: red\"></a>
                                <a title=\"Violet\" href=\"";
        // line 45
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Violet"]);
        echo "\" style=\"background-color: darkviolet\"></a>
                                <a title=\"Rose\" href=\"";
        // line 46
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Rose"]);
        echo "\" style=\"background-color: #F33A6A\"></a>
                                <a title=\"Orange\" href=\"";
        // line 47
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Orange"]);
        echo "\" style=\"background-color: #FF5F1F\"></a>
                                <a title=\"Jaune\" href=\"";
        // line 48
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Jaune"]);
        echo "\" style=\"background-color: yellow\"></a>
                                <a title=\"Blanc\" href=\"";
        // line 49
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsCouleur", ["couleur" => "Blanc"]);
        echo "\" style=\"background-color: white\"></a>

                            </div>
                        </div>
                        <div class=widgetinfowrap>
                            <div class=bg-blackimg>Chercher par Taille</div>
                            <div class=sizepic>
                                <a href=\"";
        // line 56
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsTaille", ["taille" => "XS"]);
        echo "\">XS</a>
                                <a href=\"";
        // line 57
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsTaille", ["taille" => "S"]);
        echo "\">S</a>
                                <a href=\"";
        // line 58
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsTaille", ["taille" => "M"]);
        echo "\">M</a>
                                <a href=\"";
        // line 59
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsTaille", ["taille" => "L"]);
        echo "\">L</a>
                                <a href=\"";
        // line 60
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsTaille", ["taille" => "XL"]);
        echo "\">XL</a>
                            </div>
                        </div>
                    </aside>
                    <aside class=contentinner>
                        <div class=\"bg-red shop_select clearfix\">
                            <div class=select_shopping>
                                    <div class=form-group style=\"width: 100%\">
                                        <label class=headline01 style=\"width: 20%\">Trier par :</label>
                                        <a href=\"";
        // line 69
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsTrierPrixASC");
        echo "\" class=headline01>Prix ASC</a>
                                        &ensp;&ensp;
                                        <a href=\"";
        // line 71
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsTrierPrixASC");
        echo "\" class=headline01>Prix DESC</a>
                                        &ensp;&ensp;
                                        <a href=\"";
        // line 73
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsTrierNbrEtoilesASC");
        echo "\" class=headline01>Nombre d'Etoiles ASC</a>
                                        &ensp;&ensp;
                                        <a href=\"";
        // line 75
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AfficherProduitsTrierNbrEtoilesDESC");
        echo "\" class=headline01>Nombre d'Etoiles DESC</a>

                                    </div>
                            </div>
                        </div>
                        <div class=\"shop-wrap-slider clearfix\">
                            <div class=shop_detais>
                                ";
        // line 82
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 82, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["p"]) {
            // line 83
            echo "
                                    <div class=\"shop01 clearfix\">
                                        <div class=shop-img>
                                            <div class=bgimg style=background:url(";
            // line 86
            echo twig_escape_filter($this->env, ($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("uploads/images/") . twig_get_attribute($this->env, $this->source, $context["p"], "photo", [], "any", false, false, false, 86)), "html", null, true);
            echo ")></div>
                                        </div>
                                        <div class=shop_info><h4 class=headline01><a href='#'>";
            // line 88
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["p"], "nom", [], "any", false, false, false, 88), "html", null, true);
            echo "</a></h4>

                                            <div class=star>
                                                ";
            // line 91
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(range(0, (twig_get_attribute($this->env, $this->source, $context["p"], "nbrEtoiles", [], "any", false, false, false, 91) - 1)));
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 92
                echo "                                                    <i class=\"fa fa-star\"></i>
                                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 94
            echo "                                            </div>
                                            <p>Taille: ";
            // line 95
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["p"], "taille", [], "any", false, false, false, 95), "html", null, true);
            echo "</p>
                                            <p>";
            // line 96
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["p"], "description", [], "any", false, false, false, 96), "html", null, true);
            echo "</p>

                                            <div class=headline01>\$";
            // line 98
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["p"], "prix", [], "any", false, false, false, 98), "html", null, true);
            echo "</div>
                                            <div class=addcart-wrap>
                                                <a href=\"";
            // line 100
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AjouterAuPanier", ["id" => twig_get_attribute($this->env, $this->source, $context["p"], "id", [], "any", false, false, false, 100)]), "html", null, true);
            echo "\" class=\"btn-addcart\" style=\"width: 200px\">Ajouter au panier</a>
                                                <a href=\"";
            // line 101
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("AjouterFavori", ["id" => twig_get_attribute($this->env, $this->source, $context["p"], "id", [], "any", false, false, false, 101)]), "html", null, true);
            echo "\" class=btn-fav style=\"width: 300px\"><div style=\"margin-left: 25px\">Ajouter à la liste de souhaits</div></a>
                                            </div>
                                        </div>
                                    </div>

                                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['p'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 107
        echo "                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "produit/afficherFront.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  318 => 107,  306 => 101,  302 => 100,  297 => 98,  292 => 96,  288 => 95,  285 => 94,  278 => 92,  274 => 91,  268 => 88,  263 => 86,  258 => 83,  254 => 82,  244 => 75,  239 => 73,  234 => 71,  229 => 69,  217 => 60,  213 => 59,  209 => 58,  205 => 57,  201 => 56,  191 => 49,  187 => 48,  183 => 47,  179 => 46,  175 => 45,  171 => 44,  167 => 43,  163 => 42,  159 => 41,  155 => 40,  151 => 39,  132 => 22,  122 => 21,  110 => 15,  106 => 13,  100 => 11,  98 => 10,  94 => 9,  91 => 8,  81 => 7,  70 => 4,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front.html.twig' %}

{% block activeBoutique %}
class=active
{% endblock %}

{% block panier %}

    <li><a href=\"{{ path('EnrichirPanier') }}\"><i class=\"fa fa-shopping-cart\"></i> <span>cart(<span>
                        {% if panier|length > 0 %}
                            {{ panier|length }}
                        {% else %}
                            0
                        {% endif %}
                </span>)</span></a></li>

{% endblock %}



{% block content %}

    <div class=innerbannerwrap>
        <div class=content></div>
        <div class=innerbanner><h2 class=bannerHeadline>Notre <span>Boutique</span></h2></div>
    </div>
    <section class=innerpage_all_wrap>
        <div class=container>
            <div class=row><h2 class=heading>Meilleur Boutique <span>d'Accessoires de Football</span></h2>

                <p class=headParagraph></p>

                <div class=innerWrapper>
                    <aside class=\"widgetinner clearfix\">
                        <div class=widgetinfowrap>
                            <div class=bg-blackimg>Chercher par Couleur</div>
                            <div class=sizepic>

                                <a title=\"Noir\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Noir'}) }}\" style=\"background-color: black\"></a>
                                <a title=\"Gris\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Gris'}) }}\" style=\"background-color: grey\"></a>
                                <a title=\"Marron\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Marron'}) }}\" style=\"background-color: saddlebrown\"></a>
                                <a title=\"Vert\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Vert'}) }}\" style=\"background-color: green\"></a>
                                <a title=\"Bleu\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Bleu'}) }}\" style=\"background-color: blue\"></a>
                                <a title=\"Rouge\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Rouge'}) }}\" style=\"background-color: red\"></a>
                                <a title=\"Violet\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Violet'}) }}\" style=\"background-color: darkviolet\"></a>
                                <a title=\"Rose\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Rose'}) }}\" style=\"background-color: #F33A6A\"></a>
                                <a title=\"Orange\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Orange'}) }}\" style=\"background-color: #FF5F1F\"></a>
                                <a title=\"Jaune\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Jaune'}) }}\" style=\"background-color: yellow\"></a>
                                <a title=\"Blanc\" href=\"{{ path('AfficherProduitsCouleur',{'couleur':'Blanc'}) }}\" style=\"background-color: white\"></a>

                            </div>
                        </div>
                        <div class=widgetinfowrap>
                            <div class=bg-blackimg>Chercher par Taille</div>
                            <div class=sizepic>
                                <a href=\"{{ path('AfficherProduitsTaille',{'taille':'XS'}) }}\">XS</a>
                                <a href=\"{{ path('AfficherProduitsTaille',{'taille':'S'}) }}\">S</a>
                                <a href=\"{{ path('AfficherProduitsTaille',{'taille':'M'}) }}\">M</a>
                                <a href=\"{{ path('AfficherProduitsTaille',{'taille':'L'}) }}\">L</a>
                                <a href=\"{{ path('AfficherProduitsTaille',{'taille':'XL'}) }}\">XL</a>
                            </div>
                        </div>
                    </aside>
                    <aside class=contentinner>
                        <div class=\"bg-red shop_select clearfix\">
                            <div class=select_shopping>
                                    <div class=form-group style=\"width: 100%\">
                                        <label class=headline01 style=\"width: 20%\">Trier par :</label>
                                        <a href=\"{{ path('AfficherProduitsTrierPrixASC') }}\" class=headline01>Prix ASC</a>
                                        &ensp;&ensp;
                                        <a href=\"{{ path('AfficherProduitsTrierPrixASC') }}\" class=headline01>Prix DESC</a>
                                        &ensp;&ensp;
                                        <a href=\"{{ path('AfficherProduitsTrierNbrEtoilesASC') }}\" class=headline01>Nombre d'Etoiles ASC</a>
                                        &ensp;&ensp;
                                        <a href=\"{{ path('AfficherProduitsTrierNbrEtoilesDESC') }}\" class=headline01>Nombre d'Etoiles DESC</a>

                                    </div>
                            </div>
                        </div>
                        <div class=\"shop-wrap-slider clearfix\">
                            <div class=shop_detais>
                                {% for p in produit %}

                                    <div class=\"shop01 clearfix\">
                                        <div class=shop-img>
                                            <div class=bgimg style=background:url({{ asset('uploads/images/') ~ p.photo }})></div>
                                        </div>
                                        <div class=shop_info><h4 class=headline01><a href='#'>{{ p.nom }}</a></h4>

                                            <div class=star>
                                                {% for i in 0..p.nbrEtoiles-1 %}
                                                    <i class=\"fa fa-star\"></i>
                                                {% endfor %}
                                            </div>
                                            <p>Taille: {{ p.taille }}</p>
                                            <p>{{ p.description }}</p>

                                            <div class=headline01>\${{ p.prix }}</div>
                                            <div class=addcart-wrap>
                                                <a href=\"{{ path('AjouterAuPanier',{'id':p.id}) }}\" class=\"btn-addcart\" style=\"width: 200px\">Ajouter au panier</a>
                                                <a href=\"{{ path('AjouterFavori',{'id':p.id}) }}\" class=btn-fav style=\"width: 300px\"><div style=\"margin-left: 25px\">Ajouter à la liste de souhaits</div></a>
                                            </div>
                                        </div>
                                    </div>

                                {% endfor %}
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>


{% endblock %}



", "produit/afficherFront.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\produit\\afficherFront.html.twig");
    }
}
