<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* front/home.html.twig */
class __TwigTemplate_aacae756add9ca49b87139c3e9d44229181a8d2e530c2731e2b0cb2df6a87482 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/home.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "front/home.html.twig"));

        $this->parent = $this->loadTemplate("base-front2.html.twig", "front/home.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "

\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t<div class=\"overlay\"></div>
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t<h1 class=\"mb-2 bread\">Accueil</h1>
\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t<a href=\"index.html\">Accueil
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>


\t<section class=\"ftco-section ftco-wrap-about ftco-no-pb ftco-no-pt\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters\">
\t\t\t\t<div class=\"col-sm-4 p-4 p-md-5 d-flex align-items-center justify-content-center bg-primary\">
\t\t\t\t\t<img src=\"front-office-v2/images/logojfx-light.png\" class=\"img-fluid\" alt=\"\" style=\"filter: brightness(6);\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-sm-8 wrap-about py-5 ftco-animate img\" style=\"background-image: url(front-office-v2/images/about.jpg);\">
\t\t\t\t\t<div class=\"row pb-5 pb-md-0\">
\t\t\t\t\t\t<div class=\"col-md-12 col-lg-7\">
\t\t\t\t\t\t\t<div class=\"heading-section mt-5 mb-4\">
\t\t\t\t\t\t\t\t<div class=\"pl-lg-3 ml-md-5\">
\t\t\t\t\t\t\t\t\t<span class=\"subheading\">Bienvenu</span>
\t\t\t\t\t\t\t\t\t<h2 class=\"mb-4\">Bienvenu a Cuisinet</h2>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"pl-lg-3 ml-md-5\">
\t\t\t\t\t\t\t\t<p>On her way she met a copy. The copy warned the Little Blind Text, that where it came from it would have been rewritten a thousand times and everything that was left from its origin would be the word \"and\" and the Little Blind Text should turn around and return to its own, safe country. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>

\t<section class=\"home\">

\t\t<div class=\"cuisinet-banner\">
\t\t\t<div class=\"cuisinet-banner-text\">
\t\t\t\t<h1>Bienvenu à Cuisinet</h1>
\t\t\t\t<p>
\t\t\t\t\tChez Cuisinet, il n’y a d’autre ambition que celle de proposer une cuisine
\t\t\t\t\t<br>
\t\t\t\t\tsincère, ancrée dans les saisons, authentique mais moderne, joyeuse<br>
\t\t\t\t\tet généreuse, aux inspirations larges.
\t\t\t\t\t\t\t\t\t\t\t                Ici, vous trouverez des plats de cuisine authentiques et de qualité.
\t\t\t\t\t<br>
\t\t\t\t\tPour vous et vos amis.

\t\t\t\t</p>
\t\t\t</div>

\t\t</div>
\t</section>


";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "front/home.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 4,  58 => 3,  35 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front2.html.twig' %}

{% block content %}


\t<section class=\"hero-wrap hero-wrap-2\" style=\"background-image: url('front-office-v2/images/bg_5.jpg');\" data-stellar-background-ratio=\"0.5\">
\t\t<div class=\"overlay\"></div>
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters slider-text align-items-end justify-content-center\">
\t\t\t\t<div class=\"col-md-9 ftco-animate text-center mb-5\">
\t\t\t\t\t<h1 class=\"mb-2 bread\">Accueil</h1>
\t\t\t\t\t<p class=\"breadcrumbs\">
\t\t\t\t\t\t<span class=\"mr-2\">
\t\t\t\t\t\t\t<a href=\"index.html\">Accueil
\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t</span>
\t\t\t\t\t</p>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>


\t<section class=\"ftco-section ftco-wrap-about ftco-no-pb ftco-no-pt\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row no-gutters\">
\t\t\t\t<div class=\"col-sm-4 p-4 p-md-5 d-flex align-items-center justify-content-center bg-primary\">
\t\t\t\t\t<img src=\"front-office-v2/images/logojfx-light.png\" class=\"img-fluid\" alt=\"\" style=\"filter: brightness(6);\">
\t\t\t\t</div>
\t\t\t\t<div class=\"col-sm-8 wrap-about py-5 ftco-animate img\" style=\"background-image: url(front-office-v2/images/about.jpg);\">
\t\t\t\t\t<div class=\"row pb-5 pb-md-0\">
\t\t\t\t\t\t<div class=\"col-md-12 col-lg-7\">
\t\t\t\t\t\t\t<div class=\"heading-section mt-5 mb-4\">
\t\t\t\t\t\t\t\t<div class=\"pl-lg-3 ml-md-5\">
\t\t\t\t\t\t\t\t\t<span class=\"subheading\">Bienvenu</span>
\t\t\t\t\t\t\t\t\t<h2 class=\"mb-4\">Bienvenu a Cuisinet</h2>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"pl-lg-3 ml-md-5\">
\t\t\t\t\t\t\t\t<p>On her way she met a copy. The copy warned the Little Blind Text, that where it came from it would have been rewritten a thousand times and everything that was left from its origin would be the word \"and\" and the Little Blind Text should turn around and return to its own, safe country. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</section>

\t<section class=\"home\">

\t\t<div class=\"cuisinet-banner\">
\t\t\t<div class=\"cuisinet-banner-text\">
\t\t\t\t<h1>Bienvenu à Cuisinet</h1>
\t\t\t\t<p>
\t\t\t\t\tChez Cuisinet, il n’y a d’autre ambition que celle de proposer une cuisine
\t\t\t\t\t<br>
\t\t\t\t\tsincère, ancrée dans les saisons, authentique mais moderne, joyeuse<br>
\t\t\t\t\tet généreuse, aux inspirations larges.
\t\t\t\t\t\t\t\t\t\t\t                Ici, vous trouverez des plats de cuisine authentiques et de qualité.
\t\t\t\t\t<br>
\t\t\t\t\tPour vous et vos amis.

\t\t\t\t</p>
\t\t\t</div>

\t\t</div>
\t</section>


{% endblock %}
", "front/home.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\front\\home.html.twig");
    }
}
