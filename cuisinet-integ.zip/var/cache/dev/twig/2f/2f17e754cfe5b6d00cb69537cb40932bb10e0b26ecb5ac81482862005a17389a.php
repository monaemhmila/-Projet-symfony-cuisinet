<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* contact_joueur/contactjoueur.html.twig */
class __TwigTemplate_065350497c2f94f72797d4a20f8db49bc6c4fe93dfa7fa5d565f307bd7c9fe08 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'activeEquipes' => [$this, 'block_activeEquipes'],
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base-front.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contact_joueur/contactjoueur.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contact_joueur/contactjoueur.html.twig"));

        $this->parent = $this->loadTemplate("base-front.html.twig", "contact_joueur/contactjoueur.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_activeEquipes($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeEquipes"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "activeEquipes"));

        // line 3
        echo "    class=active
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "<div class=innerbannerwrap>
    <div class=content></div>
    <div class=innerbanner><h2 class=heading>Détail <span>et Contact</span></h2></div>
    </div>
    <section class=playerDetails02>
        <div class=container>
            <div class=\"wrapper-container clearfix\">
                <p><br><br><br><br><br><br><br><br><br><br></p>
                        <div class=\"player02fig clearfix\">
                            <div  class=\"imgplayer bg-black clearfix\"><img src=\" ";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("front-office/images/player/player01.jpg"), "html", null, true);
        echo "\" ></div>
                        </div>

                        <div class=player02info>
                            <div class=clearfix>
                                <div class=player02info01><h6><span>name</span>";
        // line 20
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["joueur"]) || array_key_exists("joueur", $context) ? $context["joueur"] : (function () { throw new RuntimeError('Variable "joueur" does not exist.', 20, $this->source); })()), "nomJoueur", [], "any", false, false, false, 20), "html", null, true);
        echo "  ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["joueur"]) || array_key_exists("joueur", $context) ? $context["joueur"] : (function () { throw new RuntimeError('Variable "joueur" does not exist.', 20, $this->source); })()), "prenomJoueur", [], "any", false, false, false, 20), "html", null, true);
        echo "</h6><h6><span>position</span>";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["joueur"]) || array_key_exists("joueur", $context) ? $context["joueur"] : (function () { throw new RuntimeError('Variable "joueur" does not exist.', 20, $this->source); })()), "position", [], "any", false, false, false, 20), "html", null, true);
        echo "
                                    </h6><h6><span>age</span> ";
        // line 21
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["joueur"]) || array_key_exists("joueur", $context) ? $context["joueur"] : (function () { throw new RuntimeError('Variable "joueur" does not exist.', 21, $this->source); })()), "age", [], "any", false, false, false, 21), "html", null, true);
        echo "</h6></div>
                            </div>
                            <h6 class=oswald16>imformation</h6>


                            <p>";
        // line 26
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["joueur"]) || array_key_exists("joueur", $context) ? $context["joueur"] : (function () { throw new RuntimeError('Variable "joueur" does not exist.', 26, $this->source); })()), "description", [], "any", false, false, false, 26), "html", null, true);
        echo "</p>
                            <p><br><br><br></p>
                            </div>
            </div>
        </div>
    </section>

    <section class=\"latest_news bg-white\">
        <div class=container>
            <div class=row>
                <div class=contact_form><h2 class=heading>contacter <span>";
        // line 36
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["joueur"]) || array_key_exists("joueur", $context) ? $context["joueur"] : (function () { throw new RuntimeError('Variable "joueur" does not exist.', 36, $this->source); })()), "nomJoueur", [], "any", false, false, false, 36), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["joueur"]) || array_key_exists("joueur", $context) ? $context["joueur"] : (function () { throw new RuntimeError('Variable "joueur" does not exist.', 36, $this->source); })()), "prenomJoueur", [], "any", false, false, false, 36), "html", null, true);
        echo "</span></h2>
                    <p><br>
                        <br>
                        <br>
                        <br></p>

                    ";
        // line 42
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 42, $this->source); })()), 'form_start');
        echo "
                    <div data-parsley-validate=\"\" name=contact class=\"formcontact clearfix\">
                        <div class=form-group>";
        // line 44
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 44, $this->source); })()), "nom", [], "any", false, false, false, 44), 'widget');
        echo "</div>
                        <div class=form-group>";
        // line 45
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 45, $this->source); })()), "prenom", [], "any", false, false, false, 45), 'widget');
        echo "</div>
                        <div class=form-group>";
        // line 46
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 46, $this->source); })()), "objet", [], "any", false, false, false, 46), 'widget');
        echo "</div>
                        <div class=form-group>";
        // line 47
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 47, $this->source); })()), "email", [], "any", false, false, false, 47), 'widget');
        echo "</div>
                        <div class=\"form-group-lg\" style=\"background: transparent\" >
                            ";
        // line 49
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(twig_get_attribute($this->env, $this->source, (isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 49, $this->source); })()), "message", [], "any", false, false, false, 49), 'widget');
        echo "
                        </div>
                        <p><br></p>
                        ";
        // line 52
        echo $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 52, $this->source); })()), 'rest');
        echo "
                        <button type=submit class=\"btn btn-red\" id=send>Envoyer</button>
                        <div class=form-message>
                        </div>
                        <div class=form-group>
                            ";
        // line 57
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 57, $this->source); })()), "flashes", [0 => "message"], "method", false, false, false, 57));
        foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
            // line 58
            echo "                                <div class=\"alert alert-success\">
                                    ";
            // line 59
            echo twig_escape_filter($this->env, $context["message"], "html", null, true);
            echo "
                                </div>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 62
        echo "                        </div>
                    </div>

                    ";
        // line 65
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 65, $this->source); })()), 'form_end');
        echo "
                </div>
            </div>
        </div>
    </section>



";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "contact_joueur/contactjoueur.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  206 => 65,  201 => 62,  192 => 59,  189 => 58,  185 => 57,  177 => 52,  171 => 49,  166 => 47,  162 => 46,  158 => 45,  154 => 44,  149 => 42,  138 => 36,  125 => 26,  117 => 21,  109 => 20,  101 => 15,  90 => 6,  80 => 5,  69 => 3,  59 => 2,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base-front.html.twig' %}
{% block activeEquipes %}
    class=active
{% endblock %}
{% block content %}
<div class=innerbannerwrap>
    <div class=content></div>
    <div class=innerbanner><h2 class=heading>Détail <span>et Contact</span></h2></div>
    </div>
    <section class=playerDetails02>
        <div class=container>
            <div class=\"wrapper-container clearfix\">
                <p><br><br><br><br><br><br><br><br><br><br></p>
                        <div class=\"player02fig clearfix\">
                            <div  class=\"imgplayer bg-black clearfix\"><img src=\" {{ asset('front-office/images/player/player01.jpg') }}\" ></div>
                        </div>

                        <div class=player02info>
                            <div class=clearfix>
                                <div class=player02info01><h6><span>name</span>{{ joueur.nomJoueur }}  {{ joueur.prenomJoueur }}</h6><h6><span>position</span>{{ joueur.position }}
                                    </h6><h6><span>age</span> {{ joueur.age }}</h6></div>
                            </div>
                            <h6 class=oswald16>imformation</h6>


                            <p>{{ joueur.description }}</p>
                            <p><br><br><br></p>
                            </div>
            </div>
        </div>
    </section>

    <section class=\"latest_news bg-white\">
        <div class=container>
            <div class=row>
                <div class=contact_form><h2 class=heading>contacter <span>{{ joueur.nomJoueur }} {{ joueur.prenomJoueur }}</span></h2>
                    <p><br>
                        <br>
                        <br>
                        <br></p>

                    {{ form_start(form) }}
                    <div data-parsley-validate=\"\" name=contact class=\"formcontact clearfix\">
                        <div class=form-group>{{ form_widget(form.nom) }}</div>
                        <div class=form-group>{{ form_widget(form.prenom) }}</div>
                        <div class=form-group>{{ form_widget((form.objet)) }}</div>
                        <div class=form-group>{{ form_widget((form.email)) }}</div>
                        <div class=\"form-group-lg\" style=\"background: transparent\" >
                            {{ form_widget((form.message)) }}
                        </div>
                        <p><br></p>
                        {{ form_rest(form) }}
                        <button type=submit class=\"btn btn-red\" id=send>Envoyer</button>
                        <div class=form-message>
                        </div>
                        <div class=form-group>
                            {% for message in app.flashes('message') %}
                                <div class=\"alert alert-success\">
                                    {{ message }}
                                </div>
                            {% endfor %}
                        </div>
                    </div>

                    {{ form_end(form) }}
                </div>
            </div>
        </div>
    </section>



{% endblock %}
", "contact_joueur/contactjoueur.html.twig", "D:\\DEV\\symf\\cuisinet-integ\\templates\\contact_joueur\\contactjoueur.html.twig");
    }
}
