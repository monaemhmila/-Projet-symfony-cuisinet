<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;
use MercurySeries\FlashyBundle\FlashyNotifier;

class SecurityController extends AbstractController
{
    /**
     * @Route("/login", name="app_login")
     */
    public function login(AuthenticationUtils $authenticationUtils,FlashyNotifier $flashy): Response
    {
        // if ($this->getUser()) {
        //     return $this->redirectToRoute('target_path');
        // }

        // get the login error if there is one
        $error = $authenticationUtils->getLastAuthenticationError();
        // last username entered by the user
        $lastUsername = $authenticationUtils->getLastUsername();
        $flashy->success('Login', 'Please Log In Using Your Credentials');
        return $this->render('front/login.html.twig', ['last_username' => $lastUsername, 'error' => $error]);
    }

    /**
     * @Route("/logout", name="app_logout")
     */
    public function logout()
    {

        $this->addFlash('success', 'Please Log In Using Your Credentials');
        throw new \LogicException('This method can be blank - it will be intercepted by the logout key on your firewall.');
        
    }

    /**
     * @Route("/banned", name="is_banned")
     */
    public function banned(): Response
    {
        return $this->render('front/banned.html.twig');
    }
}
